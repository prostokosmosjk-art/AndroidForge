import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const OpticShemaDesktop());
}

class OpticShemaDesktop extends StatelessWidget {
  const OpticShemaDesktop({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ОптикСхема 24.25',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: const EditorView(),
    );
  }
}

class EditorView extends StatefulWidget {
  const EditorView({super.key});

  @override
  State<EditorView> createState() => _EditorViewState();
}

class _EditorViewState extends State<EditorView> {
  // Keep the localhost port unchanged between launches. IndexedDB and
  // localStorage are isolated by origin (including the TCP port number).
  static const int _port = 18425;
  HttpServer? _server;
  StreamSubscription<HttpRequest>? _requests;
  Uint8List? _html;
  String? _failure;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      // Package the EXACT original HTML. No CSS/JS rewrites or remote page.
      final asset = await rootBundle.load('assets/index.html');
      _html = asset.buffer.asUint8List(asset.offsetInBytes, asset.lengthInBytes);

      // 127.0.0.1 is a trusted localhost browser origin; it supports browser
      // storage and avoids the opaque unique-origin restrictions of file://.
      _server = await HttpServer.bind(InternetAddress.loopbackIPv4, _port);
      _requests = _server!.listen((request) async {
        try {
          if (request.method != 'GET' ||
              (request.uri.path != '/' && request.uri.path != '/index.html')) {
            request.response.statusCode = HttpStatus.notFound;
            await request.response.close();
            return;
          }
          request.response.headers.contentType =
              ContentType('text', 'html', charset: 'utf-8');
          request.response.headers.set('Cache-Control', 'no-store');
          request.response.add(_html!);
          await request.response.close();
        } catch (_) {
          try {
            await request.response.close();
          } catch (_) {}
        }
      });

      if (mounted) setState(() => _ready = true);
    } catch (error) {
      if (mounted) setState(() => _failure = error.toString());
    }
  }

  @override
  void dispose() {
    _requests?.cancel();
    _server?.close(force: true);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_failure != null) {
      return Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: SelectableText(
              'Не удалось запустить ОптикСхему:\n\n$_failure',
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }
    if (!_ready) {
      return const Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Запуск ОптикСхемы…'),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      body: InAppWebView(
        initialUrlRequest: URLRequest(
          url: WebUri('http://127.0.0.1:$_port/index.html'),
        ),
        initialSettings: InAppWebViewSettings(
          javaScriptEnabled: true,
          domStorageEnabled: true,
          supportZoom: true,
        ),
        onReceivedError: (controller, request, error) {
          debugPrint('OpticShema WebView error: ${error.description}');
        },
      ),
    );
  }
}
