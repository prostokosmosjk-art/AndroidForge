ОптикСхема v24.25 — Windows x64 Flutter ZIP для AndroidForge

ZIP содержит исходный Flutter-проект, а НЕ собранный EXE.
Исходный HTML ОптикСхемы сохранен побайтно (assets/index.html), включая паспорт.

На https://professional-x.github.io/AndroidForge/ :
1. Загрузить этот ZIP в сборщик.
2. Выбрать Desktop -> Windows x64 (не Android APK).
3. После завершения скачать ZIP результата и распаковать ВСЮ папку.
4. Запускать OpticShema.exe рядом с папкой data и DLL.

Сайт использует Flutter 3.27.0; здесь совместимый с Dart 3.6 пакет
flutter_inappwebview 6.1.5 (его реализация для Windows — WebView2).
На Windows требуется Microsoft Edge WebView2 Runtime.
Native Android bridge, импорт/экспорт файлов, геолокация и карты могут
потребовать адаптации — реальный запуск EXE пока не проверен.

Исходник приложения: assets/index.html
Локальная страница: http://127.0.0.1:18425/index.html
HTTP-сервер доступен только с этого ПК (localhost).
Постоянный порт нужен для сохранения IndexedDB между запусками.
Если порт занят, программа выдаст сообщение об ошибке.

Windows wrapper: experimental build #2; HTML version 24.25

Для локальной сборки из папки проекта в Windows:
  flutter pub get
  flutter build windows --release
