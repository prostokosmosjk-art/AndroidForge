// Windows x64 Flutter host for the unchanged OpticShema HTML editor.
// The Flutter engine's HWND is parented to a native resizable Win32 window.
#include <windows.h>
#include <objbase.h>
#include <flutter/dart_project.h>
#include <flutter/flutter_view_controller.h>
#include <memory>
#include <cstdlib>
#include <optional>
#include "flutter/generated_plugin_registrant.h"

static std::unique_ptr<flutter::FlutterViewController> g_controller;

LRESULT CALLBACK MainWndProc(HWND hwnd, UINT message, WPARAM wparam,
                             LPARAM lparam) noexcept {
  if (g_controller) {
    const std::optional<LRESULT> result =
        g_controller->HandleTopLevelWindowProc(
            hwnd, message, wparam, lparam);
    if (result.has_value()) return result.value();
  }

  switch (message) {
    case WM_SIZE: {
      if (g_controller && g_controller->view()) {
        RECT rect;
        GetClientRect(hwnd, &rect);
        HWND child = g_controller->view()->GetNativeWindow();
        if (child) {
          MoveWindow(child, 0, 0, rect.right - rect.left,
                     rect.bottom - rect.top, TRUE);
        }
      }
      return 0;
    }
    case WM_DESTROY:
      g_controller.reset();
      PostQuitMessage(0);
      return 0;
    default:
      return DefWindowProcW(hwnd, message, wparam, lparam);
  }
}

int APIENTRY wWinMain(HINSTANCE instance, HINSTANCE, wchar_t*, int show_cmd) {
  CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

  const wchar_t* class_name = L"OpticShemaFlutterWin";
  WNDCLASSEXW klass = {};
  klass.cbSize = sizeof(klass);
  klass.lpfnWndProc = MainWndProc;
  klass.hInstance = instance;
  klass.lpszClassName = class_name;
  klass.hCursor = LoadCursor(nullptr, IDC_ARROW);
  klass.hIcon = LoadIcon(instance, MAKEINTRESOURCE(101));
  klass.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
  if (!RegisterClassExW(&klass)) {
    CoUninitialize();
    return EXIT_FAILURE;
  }

  HWND window = CreateWindowExW(
      0, class_name, L"ОптикСхема 24.25",
      WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
      CW_USEDEFAULT, CW_USEDEFAULT, 1420, 860,
      nullptr, nullptr, instance, nullptr);
  if (!window) {
    CoUninitialize();
    return EXIT_FAILURE;
  }

  RECT rect;
  GetClientRect(window, &rect);
  flutter::DartProject project(L"data");
  g_controller = std::make_unique<flutter::FlutterViewController>(
      rect.right - rect.left, rect.bottom - rect.top, project);
  if (!g_controller->engine() || !g_controller->view()) {
    g_controller.reset();
    DestroyWindow(window);
    CoUninitialize();
    return EXIT_FAILURE;
  }

  RegisterPlugins(g_controller->engine());
  HWND child = g_controller->view()->GetNativeWindow();
  SetParent(child, window);
  SetWindowPos(child, nullptr, 0, 0, rect.right - rect.left,
               rect.bottom - rect.top, SWP_NOZORDER | SWP_SHOWWINDOW);
  ShowWindow(window, show_cmd ? show_cmd : SW_SHOW);
  UpdateWindow(window);
  g_controller->ForceRedraw();

  MSG msg;
  while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
    TranslateMessage(&msg);
    DispatchMessageW(&msg);
  }
  g_controller.reset();
  CoUninitialize();
  return static_cast<int>(msg.wParam);
}
