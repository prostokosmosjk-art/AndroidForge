package ru.opticshema.app

import android.graphics.Bitmap
import android.graphics.BitmapRegionDecoder
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * One PNG zlib stream assembled in the Android download service, one completed
 * tile ROW at a time. No full-size bitmap, no WebView/JS PNG reconversion.
 * A bounded RGB scanline band is used, with per-tile PNG region decoders.
 * On process restart the .part file is replaced and downloaded tiles are
 * replayed from private storage, rather than downloading them again.
 */
internal class MapAreaPngWriter(private val folder: File, geometry: JSONObject) {
    val z: Int = geometry.getInt("z")
    val quality: Int = geometry.getInt("q")
    val width: Int = geometry.getInt("width")
    val height: Int = geometry.getInt("height")
    private val minTX: Long = geometry.getLong("minTX")
    private val maxTX: Long = geometry.getLong("maxTX")
    private val minTY: Long = geometry.getLong("minTY")
    private val maxTY: Long = geometry.getLong("maxTY")
    private val tileSize = 256 * quality
    private val startX = floor(geometry.getDouble("x0") * quality).toLong()
    private val startY = floor(geometry.getDouble("y0") * quality).toLong()
    private val temp = File(folder, "region.png.part")
    val outputFile = File(folder, "region.png")
    private val output: BufferedOutputStream
    private val idat: IdatChunkStream
    private val zlib: DeflaterOutputStream
    var rowsCompleted: Int = 0
        private set
    private var closed = false

    init {
        require(z in 0..20 && quality in 1..2 && width > 0 && height > 0) { "Некорректный размер PNG" }
        require(minTX <= maxTX && minTY <= maxTY && minTY >= 0) { "Некорректная область PNG" }
        require(minTX*tileSize <= startX && (maxTX+1)*tileSize >= startX+width.toLong() &&
            minTY*tileSize <= startY && (maxTY+1)*tileSize >= startY+height.toLong()) {
            "PNG: выделение не полностью покрыто запрошенными тайлами"
        }
        require(width.toLong() * 3L + 1L < Int.MAX_VALUE) { "PNG: длина строки превышает возможности устройства" }
        folder.mkdirs()
        temp.delete()
        outputFile.delete() // A new export is always built from a clean PNG header.
        output = BufferedOutputStream(FileOutputStream(temp), 256 * 1024)
        output.write(byteArrayOf(137.toByte(),80,78,71,13,10,26,10))
        val ihdr = ByteArray(13)
        putU32(ihdr,0,width);putU32(ihdr,4,height)
        ihdr[8]=8 // 8 bits/channel
        ihdr[9]=2 // RGB, OPAQUE map tiles
        writeChunk(output,"IHDR",ihdr,ihdr.size)
        idat=IdatChunkStream(output)
        zlib=DeflaterOutputStream(idat,Deflater(Deflater.DEFAULT_COMPRESSION,false),64*1024)
    }

    fun appendDownloadedRow(y: Long, tileLookup: (Long) -> File, isStopped: () -> Boolean) {
        require(y in minTY..maxTY) { "PNG: строка вне области" }
        val tileTop = y * tileSize
        val begin = max(0L,tileTop-startY).toInt()
        val finish = min(height.toLong(),tileTop+tileSize-startY).toInt()
        if(finish <= begin) return
        require(begin == rowsCompleted) { "PNG: нарушен порядок строк $begin/$rowsCompleted" }
        // Hold at most ~4 MiB of raw RGB at once; never allocate width*height.
        val rowLength=1+width*3
        val bandRows=max(1,min(48,(4L*1024*1024/rowLength.toLong()).toInt()))
        var start=begin
        while(start<finish) {
            if(isStopped())throw java.io.IOException("Сборка PNG остановлена")
            val count=min(bandRows,finish-start)
            val pixels=ByteArray(rowLength*count)
            // Opaque light map background for any boundary rounding.
            for(row in 0 until count){
                val rowStart=row*rowLength
                for(x in 0 until width){
                    val i=rowStart+1+x*3
                    pixels[i]=245.toByte();pixels[i+1]=246.toByte();pixels[i+2]=248.toByte()
                }
            }
            for(rawX in minTX..maxTX) {
                if(isStopped())throw java.io.IOException("Сборка PNG остановлена")
                val left=rawX*tileSize-startX
                val right=left+tileSize
                val xBegin=max(0L,left).toInt()
                val xFinish=min(width.toLong(),right).toInt()
                if(xFinish<=xBegin)continue
                val tile=tileLookup(rawX)
                if(!tile.isFile||tile.length()<=0)throw java.io.IOException("PNG: отсутствует тайл $z/$rawX/$y")
                // All requested Yandex quality modes should have exactly these raster dimensions.
                @Suppress("DEPRECATION")
                val decoder=BitmapRegionDecoder.newInstance(tile.absolutePath,false)
                    ?: throw java.io.IOException("PNG: не удалось прочитать тайл")
                try {
                    if(decoder.width!=tileSize||decoder.height!=tileSize)
                        throw java.io.IOException("PNG: тайл $z/$rawX/$y имеет ${decoder.width}×${decoder.height}, ожидалось $tileSize×$tileSize")
                    val crop=Rect((xBegin-left).toInt(),(start+startY-tileTop).toInt(),
                        (xFinish-left).toInt(),(start+count+startY-tileTop).toInt())
                    @Suppress("DEPRECATION")
                    val part=decoder.decodeRegion(crop,android.graphics.BitmapFactory.Options().apply{
                        inPreferredConfig=Bitmap.Config.ARGB_8888
                    }) ?: throw java.io.IOException("PNG: повреждён фрагмент тайла")
                    try {
                        val source=IntArray(part.width*part.height)
                        part.getPixels(source,0,part.width,0,0,part.width,part.height)
                        if(part.width!=xFinish-xBegin||part.height!=count)
                            throw java.io.IOException("PNG: неверный размер декодированного фрагмента")
                        for(row in 0 until count){
                            val dest=row*rowLength+1+xBegin*3
                            val src=row*part.width
                            for(x in 0 until part.width){
                                val color=source[src+x];val ix=dest+x*3
                                pixels[ix]=(color ushr 16).toByte()
                                pixels[ix+1]=(color ushr 8).toByte()
                                pixels[ix+2]=color.toByte()
                            }
                        }
                    }finally{part.recycle()}
                }finally{decoder.recycle()}
            }
            drawCredit(pixels,rowLength,start,count)
            zlib.write(pixels)
            rowsCompleted=start+count
            start+=count
        }
    }

    /** Write attribution in the last rows via a small bitmap only. */
    private fun drawCredit(pixels: ByteArray, rowLength:Int,bandStart:Int,bandHeight:Int){
        val creditText="Яндекс Карты · tiles.api-maps.yandex.ru"
        val size=max(14f,min(25f,width.toFloat()/240f))
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{ textSize=size;typeface=Typeface.DEFAULT_BOLD;color=Color.rgb(23,40,60) }
        val creditW=min(width,ceil(paint.measureText(creditText)+18f).toInt())
        val creditH=min(height,ceil(size+18f).toInt())
        val creditTop=height-creditH
        if(creditW<1||bandStart>=height||bandStart+bandHeight<=creditTop)return
        val label=Bitmap.createBitmap(creditW,creditH,Bitmap.Config.ARGB_8888)
        try{
            val canvas=Canvas(label)
            canvas.drawColor(Color.rgb(248,249,250))
            canvas.drawText(creditText,9f,creditH/2f-(paint.ascent()+paint.descent())/2f,paint)
            val rowColors=IntArray(creditW)
            val from=max(bandStart,creditTop)
            val to=min(bandStart+bandHeight,height)
            for(globalRow in from until to){
                label.getPixels(rowColors,0,creditW,0,globalRow-creditTop,creditW,1)
                val dest=(globalRow-bandStart)*rowLength+1
                for(x in 0 until creditW){
                    val color=rowColors[x];val ix=dest+x*3
                    pixels[ix]=(color ushr 16).toByte()
                    pixels[ix+1]=(color ushr 8).toByte()
                    pixels[ix+2]=color.toByte()
                }
            }
        }finally{label.recycle()}
    }

    fun finish():File{
        check(!closed) { "PNG уже закрыт" }
        require(rowsCompleted==height){"PNG собран не полностью: $rowsCompleted/$height строк"}
        zlib.finish()
        idat.flushChunk()
        writeChunk(output,"IEND",ByteArray(0),0)
        output.flush();output.close();closed=true
        if(!temp.renameTo(outputFile))throw java.io.IOException("Не удалось завершить PNG-файл")
        return outputFile
    }
    fun abort(){
        if(!closed){try{zlib.close()}catch(_:Exception){};try{output.close()}catch(_:Exception){};closed=true}
        temp.delete()
    }

    private class IdatChunkStream(private val file:OutputStream):OutputStream(){
        private val buffer=ByteArray(64*1024)
        private var length=0
        override fun write(value:Int){buffer[length++]=value.toByte();if(length==buffer.size)flushChunk()}
        override fun write(bytes:ByteArray,off:Int,len:Int){
            var at=off;val end=off+len
            while(at<end){val n=min(end-at,buffer.size-length)
                System.arraycopy(bytes,at,buffer,length,n)
                length+=n;at+=n
                if(length==buffer.size)flushChunk()
            }
        }
        fun flushChunk(){if(length>0){writeChunk(file,"IDAT",buffer,length);length=0}}
        override fun close(){flushChunk()}
    }
    companion object {
        private fun putU32(buf:ByteArray,at:Int,v:Int){
            buf[at]=(v ushr 24).toByte();buf[at+1]=(v ushr 16).toByte();buf[at+2]=(v ushr 8).toByte();buf[at+3]=v.toByte()
        }
        private fun writeChunk(output:OutputStream,type:String,bytes:ByteArray,length:Int){
            val head=ByteArray(8)
            putU32(head,0,length)
            val ascii=type.toByteArray(StandardCharsets.US_ASCII)
            System.arraycopy(ascii,0,head,4,4)
            output.write(head);if(length>0)output.write(bytes,0,length)
            val crc=CRC32();crc.update(ascii);if(length>0)crc.update(bytes,0,length)
            val check=ByteArray(4);putU32(check,0,crc.value.toInt());output.write(check)
        }
    }
}
