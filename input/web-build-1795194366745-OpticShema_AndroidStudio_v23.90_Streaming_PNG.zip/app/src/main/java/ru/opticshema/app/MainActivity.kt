package ru.opticshema.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.net.Uri
import android.content.Intent
import android.provider.OpenableColumns
import java.io.File
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.io.IOException
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val key = hexToBytes("065fa03008020775cbb811df1b4b186cf4e650352f650f07a3e68c07eeb91140")
    private val pickFile = 8012
    private val saveFileRequest = 8013
    private val gpsPermissionRequest = 8014
    private var pendingGpsRequest = false
    private var pendingGpsWatchRequest = false
    @Volatile private var gpsWatchRequested = false
    private var gpsWatchManager: LocationManager? = null
    private var gpsWatchListener: LocationListener? = null
    @Volatile private var pendingSaveBytes: ByteArray? = null
    @Volatile private var pendingSaveDiskFile: File? = null
    private var streamSaveFile: File? = null
    private var streamSaveOutput: java.io.FileOutputStream? = null
    private var expectedStreamBytes: Long = -1L
    private var receivedStreamBytes: Long = 0L
    private val tileHttpPool = Executors.newFixedThreadPool(3)
    private val saveBufferLock = Any()
    private var saveBuffer: ByteArrayOutputStream? = null
    private var saveFileName: String = "OpticShema-export"
    private var saveMimeType: String = "application/octet-stream"
    private var expectedBase64Length: Int = -1
    private var receivedBase64Length: Int = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemUI()
        web = WebView(this)
        web.setBackgroundColor(android.graphics.Color.rgb(16,23,32))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.setGeolocationEnabled(true)
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.allowFileAccessFromFileURLs = false
        web.settings.allowUniversalAccessFromFileURLs = false
        web.settings.setSupportZoom(false)
        web.settings.builtInZoomControls = false
        web.settings.displayZoomControls = false
        WebView.setWebContentsDebuggingEnabled(false)
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(OpticFileBridge(), "OpticFileBridge")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivityForResult(intent, pickFile)
                    true
                } catch (e: Exception) {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = null
                    false
                }
            }
        }
        setContentView(web)
        @Suppress("DEPRECATION")
        window.decorView.setOnSystemUiVisibilityChangeListener { visibility ->
            val required = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            if ((visibility and required) != required) hideSystemUI()
        }
        try {
            val packed = assets.open("app.enc").use { it.readBytes() }
            val nonce = packed.copyOfRange(0,12)
            val cipherText = packed.copyOfRange(12,packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key,"AES"), GCMParameterSpec(128,nonce))
            val page = cipher.doFinal(cipherText).toString(Charsets.UTF_8)
            web.loadDataWithBaseURL("https://appassets.androidplatform.net/", page, "text/html", "UTF-8", null)
        } catch (e: Exception) {
            web.loadData("<meta charset='utf-8'><body style='background:#101720;color:white;font:18px sans-serif;padding:24px'>Не удалось открыть приложение. Переустановите сборку.</body>","text/html","UTF-8")
        }
    }

    private fun startNativeGpsRequest() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (!fine && !coarse) {
                pendingGpsRequest = true
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), gpsPermissionRequest)
                return
            }
        }
        requestNativeLocation()
    }

    @SuppressLint("MissingPermission")
    private fun requestNativeLocation() {
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        val hasFine = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) {
            sendGpsError("Разрешение на местоположение не предоставлено.")
            return
        }
        val provider = when {
            hasFine && manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        }
        if (provider == null) {
            sendGpsError("Включи геолокацию в настройках Android.")
            return
        }
        try {
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    try { manager.removeUpdates(this) } catch (_: Exception) { }
                    val lat = location.latitude
                    val lon = location.longitude
                    val accuracy = if (location.accuracy > 0f) location.accuracy.toDouble() else 0.0
                    web.evaluateJavascript("window.__opticNativeGpsResult && window.__opticNativeGpsResult($lat,$lon,$accuracy)", null)
                }
                @Deprecated("Deprecated by Android")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }
                override fun onProviderEnabled(provider: String) { }
                override fun onProviderDisabled(provider: String) { }
            }
            manager.requestSingleUpdate(provider, listener, Looper.getMainLooper())
            manager.getLastKnownLocation(provider)?.let { cached ->
                if (System.currentTimeMillis() - cached.time < 120_000L) {
                    try { manager.removeUpdates(listener) } catch (_: Exception) { }
                    val lat = cached.latitude
                    val lon = cached.longitude
                    val accuracy = if (cached.accuracy > 0f) cached.accuracy.toDouble() else 0.0
                    web.evaluateJavascript("window.__opticNativeGpsResult && window.__opticNativeGpsResult($lat,$lon,$accuracy)", null)
                }
            }
        } catch (e: Exception) {
            sendGpsError(e.message ?: "Не удалось получить координаты Android.")
        }
    }


    private fun startNativeGpsWatch() {
        gpsWatchRequested = true
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (!fine && !coarse) {
                pendingGpsWatchRequest = true
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), gpsPermissionRequest)
                return
            }
        }
        requestNativeLocationUpdates()
    }

    @SuppressLint("MissingPermission")
    private fun requestNativeLocationUpdates() {
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        val hasFine = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) {
            sendGpsError("Разрешение на местоположение не предоставлено.")
            return
        }
        val provider = when {
            hasFine && manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        }
        if (provider == null) {
            sendGpsError("Включи геолокацию в настройках Android.")
            return
        }
        try {
            stopNativeGpsListenerOnly()
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    val lat = location.latitude
                    val lon = location.longitude
                    val accuracy = if (location.accuracy > 0f) location.accuracy.toDouble() else 0.0
                    web.evaluateJavascript("window.__opticNativeGpsResult && window.__opticNativeGpsResult($lat,$lon,$accuracy)", null)
                }
                @Deprecated("Deprecated by Android")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }
                override fun onProviderEnabled(provider: String) { }
                override fun onProviderDisabled(provider: String) { }
            }
            gpsWatchManager = manager
            gpsWatchListener = listener
            manager.requestLocationUpdates(provider, 3000L, 2f, listener, Looper.getMainLooper())
            manager.getLastKnownLocation(provider)?.let { cached ->
                if (System.currentTimeMillis() - cached.time < 120_000L) {
                    val lat = cached.latitude
                    val lon = cached.longitude
                    val accuracy = if (cached.accuracy > 0f) cached.accuracy.toDouble() else 0.0
                    web.evaluateJavascript("window.__opticNativeGpsResult && window.__opticNativeGpsResult($lat,$lon,$accuracy)", null)
                }
            }
        } catch (e: Exception) {
            sendGpsError(e.message ?: "Не удалось запустить обновление координат Android.")
        }
    }

    private fun stopNativeGpsListenerOnly() {
        try {
            val manager = gpsWatchManager
            val listener = gpsWatchListener
            if (manager != null && listener != null) manager.removeUpdates(listener)
        } catch (_: Exception) { }
        gpsWatchManager = null
        gpsWatchListener = null
    }

    private fun stopNativeGpsWatch() {
        gpsWatchRequested = false
        pendingGpsWatchRequest = false
        stopNativeGpsListenerOnly()
    }

    private fun sendGpsError(message: String) {
        web.evaluateJavascript("window.__opticNativeGpsError && window.__opticNativeGpsError(" + org.json.JSONObject.quote(message) + ")", null)
    }

    @Deprecated("Deprecated by Android")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == gpsPermissionRequest) {
            pendingGpsRequest = false
            val wasWatchRequest = pendingGpsWatchRequest
            pendingGpsWatchRequest = false
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
                if (wasWatchRequest) requestNativeLocationUpdates() else requestNativeLocation()
            } else {
                gpsWatchRequested = false
                sendGpsError("Доступ к местоположению запрещён. Разреши GPS в настройках приложения.")
            }
        }
    }

    private fun hideSystemUI() {
        val decor = window.decorView
        decor.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    override fun onPause() {
        // Avoid keeping GPS active while the app is backgrounded; resume the watch when foregrounded.
        if (gpsWatchRequested) stopNativeGpsListenerOnly()
        // Flush the schematic and map drafts to IndexedDB before the WebView is backgrounded.
        if (::web.isInitialized) {
            try {
                web.evaluateJavascript("window.__opticFlushDrafts && window.__opticFlushDrafts().catch(function(e){console.warn('Draft flush failed',e)})", null)
            } catch (_: Exception) { }
        }
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) hideSystemUI()
        if (gpsWatchRequested) requestNativeLocationUpdates()
    }
    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode == pickFile) {
            var webViewUris: Array<Uri>? = null
            if (resultCode == RESULT_OK && data != null) {
                val selectedUri = data.data
                    ?: data.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
                if (selectedUri != null) {
                    try {
                        // Do not let WebView read an arbitrary provider URI directly.
                        // Read it through Android ContentResolver and hand WebView a local copy.
                        var displayName = "OpticShema-project.optic"
                        try {
                            contentResolver.query(selectedUri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                                if (cursor.moveToFirst()) {
                                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                                    if (index >= 0) displayName = cursor.getString(index) ?: displayName
                                }
                            }
                        } catch (_: Exception) { }

                        val safeName = displayName.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
                            .ifBlank { "OpticShema-project.optic" }
                        val extension = safeName.substringAfterLast('.', "optic").take(12)
                        val importDir = File(cacheDir, "project_import").apply { mkdirs() }
                        importDir.listFiles()?.forEach { old ->
                            if (old.isFile && System.currentTimeMillis() - old.lastModified() > 24L * 60L * 60L * 1000L) old.delete()
                        }
                        val localFile = File.createTempFile("optic_import_", ".$extension", importDir)
                        val input = contentResolver.openInputStream(selectedUri)
                            ?: throw IllegalStateException("Файловый менеджер не открыл выбранный файл")
                        input.use { source ->
                            localFile.outputStream().use { target -> source.copyTo(target) }
                        }
                        if (!localFile.isFile || localFile.length() <= 0L) {
                            localFile.delete()
                            throw IllegalStateException("Android прочитал выбранный файл как пустой")
                        }
                        webViewUris = arrayOf(Uri.fromFile(localFile))
                    } catch (e: Exception) {
                        web.evaluateJavascript(
                            "console.error('Ошибка чтения выбранного файла: ' + " +
                                org.json.JSONObject.quote(e.message ?: "неизвестная ошибка") + ")",
                            null
                        )
                        webViewUris = null
                    }
                }
            }
            fileCallback?.onReceiveValue(webViewUris)
            fileCallback = null
        } else if (requestCode == saveFileRequest) {
            val diskFile = pendingSaveDiskFile
            pendingSaveDiskFile = null
            val bytes = pendingSaveBytes
            pendingSaveBytes = null
            val targetUri = data?.data
                ?: data?.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
            if (diskFile != null) {
                if (resultCode == RESULT_OK && targetUri != null && diskFile.isFile) {
                    // Large copy runs off the UI thread. Progress is reported to WebView.
                    tileHttpPool.execute {
                        try {
                            val output = try { contentResolver.openOutputStream(targetUri, "wt") }
                                catch (_: Exception) { null }
                                ?: contentResolver.openOutputStream(targetUri, "w")
                                ?: throw IllegalStateException("Android не открыл запись файла")
                            var copied = 0L
                            var lastPercent = -1
                            output.use { target ->
                                diskFile.inputStream().use { source ->
                                    val buffer = ByteArray(256 * 1024)
                                    while (true) {
                                        val n = source.read(buffer)
                                        if (n < 0) break
                                        target.write(buffer, 0, n)
                                        copied += n
                                        val percent = ((copied * 100.0) / diskFile.length().coerceAtLeast(1L)).toInt().coerceIn(0, 100)
                                        if (percent >= lastPercent + 2 || percent == 100) {
                                            lastPercent = percent
                                            runOnUiThread { web.evaluateJavascript("window.__opticNativeSaveProgress && window.__opticNativeSaveProgress(" + percent + ")", null) }
                                        }
                                    }
                                    target.flush()
                                }
                            }
                            runOnUiThread { web.evaluateJavascript("window.__opticNativeSaveComplete && window.__opticNativeSaveComplete(true)", null) }
                        } catch (e: Exception) {
                            runOnUiThread { web.evaluateJavascript("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось сохранить файл") + ")", null) }
                        } finally {
                            diskFile.delete()
                        }
                    }
                } else {
                    diskFile.delete()
                    web.evaluateJavascript("window.__opticNativeSaveComplete && window.__opticNativeSaveComplete(false)", null)
                }
            } else if (resultCode == RESULT_OK && targetUri != null && bytes != null) {
                try {
                    // Use the URI returned by the system picker (including a user-renamed name).
                    // Truncate explicitly so provider defaults cannot append to an old document.
                    val output = try {
                        contentResolver.openOutputStream(targetUri, "wt")
                    } catch (_: Exception) {
                        null
                    } ?: contentResolver.openOutputStream(targetUri, "w")
                      ?: throw IllegalStateException("Android не открыл поток записи файла")
                    output.use { stream ->
                        stream.write(bytes)
                        stream.flush()
                    }
                    web.evaluateJavascript("window.__opticNativeSaveComplete && window.__opticNativeSaveComplete(true)", null)
                } catch (e: Exception) {
                    web.evaluateJavascript("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось сохранить файл") + ")", null)
                }
            } else {
                web.evaluateJavascript("window.__opticNativeSaveComplete && window.__opticNativeSaveComplete(false)", null)
            }
        }
    }
    private fun safeExportName(rawName: String): String {
        val leaf = rawName.substringAfterLast('/').substringAfterLast('\\')
        val cleaned = leaf
            .replace(Regex("[\\u0000-\\u001F\\u007F]"), "")
            .replace(Regex("[<>:\"|?*]"), "_")
            .trim()
            .trimEnd('.', ' ')
        return cleaned.ifBlank { "OpticShema-export" }.take(180)
    }

    // v23.83: HTTPS-only native tile transport. Restrict the JS-facing bridge to
    // the official Yandex raster Tiles API; never follow redirects to other hosts.
    private fun downloadYandexTile(requestId: String, rawUrl: String) {
        if (!requestId.matches(Regex("[A-Za-z0-9_-]{1,64}"))) return
        tileHttpPool.execute {
            var connection: HttpURLConnection? = null
            try {
                val uri = Uri.parse(rawUrl)
                if (uri.scheme != "https" || uri.host != "tiles.api-maps.yandex.ru" ||
                    uri.path != "/v1/tiles/" || rawUrl.length > 2048) {
                    throw IOException("Запрещённый адрес тайла")
                }
                val conn = URL(rawUrl).openConnection() as HttpURLConnection
                connection = conn
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 9000
                conn.readTimeout = 13000
                conn.requestMethod = "GET"
                val code = conn.responseCode
                if (code != 200) throw IOException("HTTP $code")
                val mime = conn.contentType ?: ""
                if (!mime.startsWith("image/")) throw IOException("Tiles API вернул не изображение")
                val output = ByteArrayOutputStream()
                conn.inputStream.use { stream ->
                    val chunk = ByteArray(16384)
                    while (true) {
                        val count = stream.read(chunk)
                        if (count < 0) break
                        if (output.size() + count > 1200000) throw IOException("Тайл слишком большой")
                        output.write(chunk, 0, count)
                    }
                }
                val data = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
                runOnUiThread {
                    if (::web.isInitialized) web.evaluateJavascript(
                        "window.__opticNativeTileResult && window.__opticNativeTileResult(" +
                        org.json.JSONObject.quote(requestId) + "," +
                        org.json.JSONObject.quote(data) + ",null)", null
                    )
                }
            } catch (error: Exception) {
                // Do not return raw URLs: they contain the API key.
                val safeMessage = (error.message ?: "Не удалось загрузить тайл").replace(
                    Regex("apikey=[^&\\s]+", RegexOption.IGNORE_CASE), "apikey=***"
                )
                runOnUiThread {
                    if (::web.isInitialized) web.evaluateJavascript(
                        "window.__opticNativeTileResult && window.__opticNativeTileResult(" +
                        org.json.JSONObject.quote(requestId) + ",null," +
                        org.json.JSONObject.quote(safeMessage) + ")", null
                    )
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private inner class OpticFileBridge {
        @android.webkit.JavascriptInterface
        fun fetchYandexTile(requestId: String, url: String) {
            downloadYandexTile(requestId, url)
        }

        @android.webkit.JavascriptInterface
        fun requestGps() {
            runOnUiThread { startNativeGpsRequest() }
        }

        @android.webkit.JavascriptInterface
        fun startGpsWatch() {
            runOnUiThread { startNativeGpsWatch() }
        }

        @android.webkit.JavascriptInterface
        fun stopGpsWatch() {
            runOnUiThread { stopNativeGpsWatch() }
        }

        // 23.89: disk-backed streaming save for large PNG; no arbitrary total byte cap.
        // Each JS call carries at most 48 KiB of base64, not the entire image.
        @android.webkit.JavascriptInterface
        fun beginSaveBlob(fileName: String, mimeType: String, totalBytes: String): Boolean {
            val expected = totalBytes.toLongOrNull() ?: return false
            if (expected < -1L || (expected == -1L && mimeType != "image/png")) return false
            return try {
                synchronized(saveBufferLock) {
                    try { streamSaveOutput?.close() } catch (_: Exception) { }
                    streamSaveFile?.delete()
                    val nextFile = File.createTempFile("optic_png_export_", ".part", cacheDir)
                    streamSaveFile = nextFile
                    streamSaveOutput = nextFile.outputStream()
                    saveFileName = safeExportName(fileName)
                    saveMimeType = mimeType.ifBlank { "image/png" }
                    expectedStreamBytes = expected
                    receivedStreamBytes = 0L
                }
                true
            } catch (_: Exception) {
                synchronized(saveBufferLock) {
                    try { streamSaveOutput?.close() } catch (_: Exception) { }
                    streamSaveOutput = null
                    streamSaveFile?.delete()
                    streamSaveFile = null
                    expectedStreamBytes = -1L
                    receivedStreamBytes = 0L
                }
                false
            }
        }

        @android.webkit.JavascriptInterface
        fun appendSaveBlobChunk(chunk: String): Boolean {
            if (chunk.length > 48 * 1024) return false
            return try {
                val bytes = Base64.decode(chunk, Base64.NO_WRAP)
                synchronized(saveBufferLock) {
                    val output = streamSaveOutput ?: return false
                    if (expectedStreamBytes < -1L || (expectedStreamBytes >= 0L && receivedStreamBytes > expectedStreamBytes - bytes.size)) return false
                    output.write(bytes)
                    receivedStreamBytes += bytes.size.toLong()
                }
                true
            } catch (_: Exception) { false }
        }

        @android.webkit.JavascriptInterface
        fun cancelSaveBlob() {
            synchronized(saveBufferLock) {
                try { streamSaveOutput?.close() } catch (_: Exception) { }
                streamSaveOutput = null
                streamSaveFile?.delete()
                streamSaveFile = null
                expectedStreamBytes = -1L
                receivedStreamBytes = 0L
            }
        }

        @android.webkit.JavascriptInterface
        fun finishSaveBlob(): Boolean {
            val tmp: File
            val name: String
            val mime: String
            synchronized(saveBufferLock) {
                val output = streamSaveOutput ?: return false
                tmp = streamSaveFile ?: return false
                if (expectedStreamBytes >= 0L && receivedStreamBytes != expectedStreamBytes) return false
                try { output.flush(); output.close() } catch (_: Exception) { return false }
                streamSaveOutput = null
                streamSaveFile = null
                expectedStreamBytes = -1L
                receivedStreamBytes = 0L
                if (tmp.length() <= 0L) { tmp.delete(); return false }
                name = saveFileName
                mime = saveMimeType
            }
            runOnUiThread {
                try {
                    pendingSaveDiskFile?.delete()
                    pendingSaveDiskFile = tmp
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mime
                        putExtra(Intent.EXTRA_TITLE, safeExportName(name))
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    }
                    startActivityForResult(intent, saveFileRequest)
                } catch (e: Exception) {
                    pendingSaveDiskFile = null
                    tmp.delete()
                    web.evaluateJavascript("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось открыть сохранение") + ")", null)
                }
            }
            return true
        }

        @android.webkit.JavascriptInterface
        fun beginSaveFile(fileName: String, mimeType: String, totalBase64Length: Int): Boolean {
            if (totalBase64Length < 0 || totalBase64Length > 80 * 1024 * 1024) return false
            return try {
                synchronized(saveBufferLock) {
                    saveBuffer?.reset()
                    saveBuffer = ByteArrayOutputStream()
                    saveFileName = safeExportName(fileName)
                    saveMimeType = mimeType.ifBlank { "application/octet-stream" }
                    expectedBase64Length = totalBase64Length
                    receivedBase64Length = 0
                }
                true
            } catch (_: Exception) {
                synchronized(saveBufferLock) { saveBuffer = null; expectedBase64Length = -1; receivedBase64Length = 0 }
                false
            }
        }

        @android.webkit.JavascriptInterface
        fun appendSaveFileChunk(chunk: String): Boolean {
            return try {
                synchronized(saveBufferLock) {
                    val buffer = saveBuffer ?: return false
                    if (chunk.length > 48 * 1024 || receivedBase64Length + chunk.length > expectedBase64Length) return false
                    buffer.write(Base64.decode(chunk, Base64.DEFAULT))
                    receivedBase64Length += chunk.length
                }
                true
            } catch (_: Exception) {
                synchronized(saveBufferLock) { saveBuffer?.reset(); saveBuffer = null; expectedBase64Length = -1; receivedBase64Length = 0 }
                false
            }
        }

        @android.webkit.JavascriptInterface
        fun finishSaveFile(): Boolean {
            val bytes: ByteArray
            val name: String
            val mime: String
            synchronized(saveBufferLock) {
                val buffer = saveBuffer ?: return false
                if (receivedBase64Length != expectedBase64Length) return false
                bytes = buffer.toByteArray()
                name = saveFileName
                mime = saveMimeType
                saveBuffer = null
                expectedBase64Length = -1
                receivedBase64Length = 0
            }
            runOnUiThread {
                try {
                    pendingSaveBytes = bytes
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mime
                        putExtra(Intent.EXTRA_TITLE, safeExportName(name))
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    }
                    startActivityForResult(intent, saveFileRequest)
                } catch (e: Exception) {
                    pendingSaveBytes = null
                    web.evaluateJavascript("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось открыть сохранение") + ")", null)
                }
            }
            return true
        }

        @android.webkit.JavascriptInterface
        fun saveFile(fileName: String, mimeType: String, base64Data: String) {
            runOnUiThread {
                try {
                    val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                    pendingSaveBytes = bytes
                    val safeName = safeExportName(fileName)
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mimeType.ifBlank { "application/octet-stream" }
                        putExtra(Intent.EXTRA_TITLE, safeName)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    }
                    startActivityForResult(intent, saveFileRequest)
                } catch (e: Exception) {
                    pendingSaveBytes = null
                    web.evaluateJavascript("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось подготовить файл") + ")", null)
                }
            }
        }
    }

    private fun hexToBytes(s: String): ByteArray = ByteArray(s.length/2) { i -> s.substring(i*2,i*2+2).toInt(16).toByte() }
    override fun onDestroy() { tileHttpPool.shutdownNow(); if (::web.isInitialized) web.destroy(); super.onDestroy() }
}
