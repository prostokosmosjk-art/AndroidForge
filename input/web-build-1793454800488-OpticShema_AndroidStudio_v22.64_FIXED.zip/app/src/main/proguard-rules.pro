# Keep JavaScript bridge methods callable by WebView reflection.
-keepclassmembers class ru.opticshema.app.MainActivity$OpticFileBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class ru.opticshema.app.MainActivity$OpticFileBridge { *; }
