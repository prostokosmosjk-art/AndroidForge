-keep class ru.opticshema.app.MainActivity { *; }
-keepattributes *Annotation*

# Preserve the WebView JavaScript bridge and its @JavascriptInterface methods.
# These rules are required for GPS callbacks and chunked file export in R8 release builds.
-keepclassmembers class ru.opticshema.app.MainActivity$OpticFileBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class ru.opticshema.app.MainActivity$OpticFileBridge { *; }
