package ru.opticshema.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.net.Uri
import android.content.Intent
import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val key = hexToBytes("065fa03008020775cbb811df1b4b186cf4e650352f650f07a3e68c07eeb91140")
    private val pickFile = 8012
    private val saveFileRequest = 8013
    @Volatile private var pendingSaveBytes: ByteArray? = null
    private val saveBufferLock = Any()
    private var chunkedSaveBuffer: ByteArrayOutputStream? = null
    private var chunkedSaveFileName: String = "OpticShema-export"
    private var chunkedSaveMimeType: String = "application/octet-stream"
    private var expectedBase64Length: Int = -1
    private var receivedBase64Length: Int = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemUI()
        web = WebView(this)
        web.setBackgroundColor(android.graphics.Color.rgb(16,23,32))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.allowFileAccessFromFileURLs = false
        web.settings.allowUniversalAccessFromFileURLs = false
        web.settings.setSupportZoom(false)
        web.settings.builtInZoomControls = false
        web.settings.displayZoomControls = false
        WebView.setWebContentsDebuggingEnabled(false)
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(OpticFileBridge(), "OpticFileBridge")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null); fileCallback = callback
                return try { startActivityForResult(params!!.createIntent(), pickFile); true } catch (e: Exception) { fileCallback?.onReceiveValue(null); fileCallback=null; false }
            }
        }
        setContentView(web)
        @Suppress("DEPRECATION")
        window.decorView.setOnSystemUiVisibilityChangeListener { visibility ->
            val required = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            if ((visibility and required) != required) hideSystemUI()
        }
        try {
            val packed = assets.open("app.enc").use { it.readBytes() }
            val nonce = packed.copyOfRange(0,12)
            val cipherText = packed.copyOfRange(12,packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key,"AES"), GCMParameterSpec(128,nonce))
            val page = cipher.doFinal(cipherText).toString(Charsets.UTF_8)
            web.loadDataWithBaseURL("https://appassets.androidplatform.net/", page, "text/html", "UTF-8", null)
        } catch (e: Exception) {
            web.loadData("<meta charset='utf-8'><body style='background:#101720;color:white;font:18px sans-serif;padding:24px'>Не удалось открыть приложение. Переустановите сборку.</body>","text/html","UTF-8")
        }
    }
    private fun hideSystemUI() {
        val decor = window.decorView
        decor.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    @Suppress("DEPRECATION")
    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) hideSystemUI()
    }
    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode == pickFile) {
            val result = if (resultCode == RESULT_OK && data != null) WebChromeClient.FileChooserParams.parseResult(resultCode,data) else null
            fileCallback?.onReceiveValue(result); fileCallback=null
        } else if (requestCode == saveFileRequest) {
            val bytes = pendingSaveBytes
            pendingSaveBytes = null
            if (resultCode == RESULT_OK && data?.data != null && bytes != null) {
                try {
                    val output = contentResolver.openOutputStream(data.data!!) ?: throw IllegalStateException("Не удалось открыть файл для записи")
                    output.use { it.write(bytes); it.flush() }
                    if (bytes.isEmpty()) throw IllegalStateException("Получен пустой файл")
                    web.evaluateJavascript("window.__opticNativeSaveComplete && window.__opticNativeSaveComplete(true)", null)
                } catch (e: Exception) {
                    web.evaluateJavascript("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось сохранить файл") + ")", null)
                }
            } else {
                web.evaluateJavascript("window.__opticNativeSaveComplete && window.__opticNativeSaveComplete(false)", null)
            }
        }
    }
    private fun launchSaveDialog(fileName: String, mimeType: String, bytes: ByteArray) {
        if (bytes.isEmpty()) throw IllegalArgumentException("Нельзя сохранить пустой файл")
        pendingSaveBytes = bytes
        val safeName = fileName.substringAfterLast('/').ifBlank { "OpticShema-export" }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mimeType.ifBlank { "application/octet-stream" }
            putExtra(Intent.EXTRA_TITLE, safeName)
        }
        startActivityForResult(intent, saveFileRequest)
    }

    private inner class OpticFileBridge {
        @android.webkit.JavascriptInterface
        fun beginSaveFile(fileName: String, mimeType: String, base64Length: Int): Boolean {
            return try {
                if (base64Length <= 0) return false
                synchronized(saveBufferLock) {
                    chunkedSaveBuffer = ByteArrayOutputStream()
                    chunkedSaveFileName = fileName
                    chunkedSaveMimeType = mimeType
                    expectedBase64Length = base64Length
                    receivedBase64Length = 0
                }
                true
            } catch (_: Exception) { false }
        }

        @android.webkit.JavascriptInterface
        fun appendSaveFileChunk(base64Chunk: String): Boolean {
            return try {
                synchronized(saveBufferLock) {
                    val buffer = chunkedSaveBuffer ?: return false
                    if (base64Chunk.isEmpty() || receivedBase64Length + base64Chunk.length > expectedBase64Length) return false
                    val decoded = Base64.decode(base64Chunk, Base64.DEFAULT)
                    buffer.write(decoded)
                    receivedBase64Length += base64Chunk.length
                }
                true
            } catch (_: Exception) { false }
        }

        @android.webkit.JavascriptInterface
        fun finishSaveFile(): Boolean {
            val fileName: String
            val mimeType: String
            val bytes: ByteArray
            try {
                synchronized(saveBufferLock) {
                    val buffer = chunkedSaveBuffer ?: return false
                    if (receivedBase64Length != expectedBase64Length) return false
                    bytes = buffer.toByteArray()
                    fileName = chunkedSaveFileName
                    mimeType = chunkedSaveMimeType
                    chunkedSaveBuffer = null
                    expectedBase64Length = -1
                    receivedBase64Length = 0
                }
                runOnUiThread {
                    try { launchSaveDialog(fileName, mimeType, bytes) }
                    catch (e: Exception) {
                        pendingSaveBytes = null
                        web.evaluateJavascript("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось подготовить файл") + ")", null)
                    }
                }
                true
            } catch (_: Exception) { false }
        }

        @android.webkit.JavascriptInterface
        fun saveFile(fileName: String, mimeType: String, base64Data: String) {
            runOnUiThread {
                try {
                    val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                    launchSaveDialog(fileName, mimeType, bytes)
                } catch (e: Exception) {
                    pendingSaveBytes = null
                    web.evaluateJavascript("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось подготовить файл") + ")", null)
                }
            }
        }
    }

    private fun hexToBytes(s: String): ByteArray = ByteArray(s.length/2) { i -> s.substring(i*2,i*2+2).toInt(16).toByte() }
    override fun onDestroy() { if (::web.isInitialized) web.destroy(); super.onDestroy() }
}
