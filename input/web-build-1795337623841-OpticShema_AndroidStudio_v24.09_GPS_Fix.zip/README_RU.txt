=== ТЕКУЩАЯ СБОРКА v24.09 (22.11.2026) ===
Исправлен GPS Android: Fused / сеть / спутники, новая диагностика ожидания точки. См. BUILD_24.09_RU.txt.

=== ТЕКУЩАЯ СБОРКА v24.08 (22.11.2026) ===
Встроен v24.08 в AES-GCM app.enc. Версия APK 24.08 / 2408. См. BUILD_24.08_RU.txt.



=== Update v23.82 (2026-11-20) ===
- Fixed blurred Yandex Tiles layer on high-density screens: request official scale=2 (512x512px tile on 2x displays).
- Separate 1x and 2x cache keys prevent reusing old low-resolution tile images.
- Preserved z0 world map, map interactions, network data, key storage and Android bridge.
- HTML SHA256: 08bd831dd039d9c2d193e075ee6bf4e5b8b970e1e5d088252f72e7dcd1db7b29.
- Live Yandex tiles must be verified on real Android device.



=== Update v23.81 (2026-11-20) ===
- Country/world-level zoom support (z0) added to map for both OSM and Yandex Tiles/JS API.
- Touch pinch, mouse wheel and +/- controls use same device-aware minimum zoom; saved camera restores after reopening.
- World wrap and overview map captions corrected; node/route coordinates and GPON unchanged.
- Existing key storage, Android bridge, map cache and map gesture inertia preserved.
- HTML sha256: c4edc0a759fc39231c267267c4e13a6670c1143ece9c8d314695a73423afdd1c.
- Live online Yandex tiles / real APK execution not exercised in this environment.



=== Update v23.80 (2026-11-20) ===
- Map edit toolbar fills full mobile top row, and covers standalone Back/City controls until Done.
- Fixed Photon HTTP 400 caused by unsupported ru language code; the query now omits lang.
- New on-device, on-demand Yandex JavaScript API geocoder test checks key presence, actual response, and gives hints for scriptError. Never shows key.
- Search order: loaded Yandex JS API, Photon (public OSM), Open-Meteo (GeoNames).
- GPON, RX, tile cache, geo coordinates, Android MainActivity, autosave/project persistence untouched.
- HTML sha256: e508e42c0842c196fb15a409af06f34de1277377d68a02304402aa062c0caba9.
- Offline unit/browser tests performed; real API key in user WebView and APK execution unavailable here.

ОптикСхема v23.79 — проект Android Studio.
Версия приложения: 23.79, код 2379. Внутренний HTML зашифрован AES-256-GCM.
Карта: линейка, редактор, кнопка «Город» теперь на одной верхней линии.
Поиск города: Яндекс JS API при наличии ключа/загруженной библиотеки,
Open-Meteo Geocoding, затем Photon. Тайлы Яндекс API сами по себе не дают геокодирования.
Сервисы требуют интернет и могут быть недоступны в зависимости от региона и CORS.
Это ZIP исходников, а не APK. Обновление поверх старого APK требует тот же ключ подписи.



Android Studio update v23.78 (2026-11-20):
- Same Android application and bridges as v23.77; encrypted HTML updated to v23.78 (AES-256-GCM).
- Fixed city-search initialisation ReferenceError that prevented map opening.
- Separate top-right City button; panel opens only on click and resets when opening map.
- Mobile map toolbar leaves free room for City button; browse edit/ruler controls moved below it.
- GPON, fibre/weld logic, project format, Android autosave and Yandex API-key persistence unchanged.
- Gradle versionName 23.78 / versionCode 2378, matching Manifest version note.
- SHA-256 of HTML: d65907ed407edba08083d1a2221bc4209e9e087a1a9e2e5c78c7ea8579c41fae
- 29 JS scripts syntax checked; offline mobile Chromium map-open, search-panel and camera test passed (873, 393 and 320 px).
- Live Yandex/Photon network and Android APK install not tested.



Android Studio update v23.77 (2026-11-20):
- Based on v23.76 Android Studio project; embedded v23.77 city-search HTML (AES-256-GCM app.enc).
- 23.77 / 2377 in Gradle and manifest version note.
- Lightweight on-demand town/city search on map; Yandex JS API geocoder if loaded, Photon/OSM fallback in Tiles-only mode.
- Moves camera only, network entities and map/Yandex API keys remain as in v23.76.
- Native MainActivity, GPS/file bridges, autosave, permissions and .optic schema unchanged.
- SHA-256 HTML: 5df2bc8a40b3f3572e339464a042b210ad957bc55fa7a9aae4f3024c344d4792
- 29 inline script syntax checks passed; isolated city-search click/cache/camera test passed.
- Full WebView, online services and APK install not tested in this environment.

Текущая версия: ОптикСхема v23.76 (20.11.2026)
Android versionName: 23.76; versionCode: 2376.
HTML: OpticShema_v23.76_Map_Gestures_Measurements.html; зашифрован в app/src/main/assets/app.enc прежним AES-256-GCM.
Изменения: постоянная инерция карты после зума, снижение мерцания тайлов, управление сохранёнными измерениями из кнопки «⬇».
Исходная версия Android Studio v23.75. Для обновления APK нужна прежняя подпись приложения.
Подробнее: CHANGELOG_23.76_AndroidStudio_RU.txt.

Текущая версия проекта: ОптикСхема v23.75 (20.11.2026)
Android versionName: 23.75; versionCode: 2375.
HTML: OpticShema_v23.75_Map_Inertia_Labels.html, вшит в app/src/main/assets/app.enc через существующий AES-256-GCM.
Основные изменения: одинаковая инерция карты с открытой/закрытой панелью, подписи инструментов и одна видимая кнопка возврата к схеме.
На основе архивного Android Studio v23.74; нативная логика, package ID, GPS, WebView, файловый мост, автосохранение и ключи Яндекса без изменений.
Для обновления APK поверх прежней версии нужен тот же ключ подписи.
Подробнее: CHANGELOG_23.75_AndroidStudio_RU.txt.

Текущая версия проекта: ОптикСхема v23.74 (20.11.2026)
Android versionName: 23.74; versionCode: 2374.
Основной HTML: OpticShema_v23.74_Unified_Splitter_Optimizer.html, встроен в app/src/main/assets/app.enc с AES-256-GCM.
Обновлено на основе ZIP Android Studio v23.60; сохранены нативные классы, мосты, иконки, разрешения, манифест и настройки подписания.
Сборка проекта: открыть папку в Android Studio, дождаться синхронизации Gradle и собрать APK. Для обновления уже установленной программы используйте прежний ключ подписи.
Подробнее: CHANGELOG_23.74_AndroidStudio_RU.txt.

Изменения v23.60 — Yandex Tiles Cache:
• В Android assets встроена чистая standalone-версия OpticShema v23.60 без проектных боксов и карты пользователя.
• Добавлена поддержка Tiles API Яндекса с отдельным ключом Tiles API; текущий ключ JavaScript API остаётся самостоятельным.
• Локальный кэш тайлов использует IndexedDB, срок хранения — до 30 дней; запросы ограничены по частоте.
• Android versionName/versionCode: 23.60 / 2360.
• Сохранены AES-256-GCM, native bridge, GPS/file bridge, ресурсы и .optic v17.

Изменения v23.59 — автобалансировка GPON по конечным RX:
• В Android assets встроена чистая standalone-версия OpticShema v23.59; пользовательские боксы, карта и внутренние данные конкретного проекта в APK-проект не включены.
• Android versionName/versionCode: 23.59 / 2359. Значения задаются в app/build.gradle defaultConfig; комментарий AndroidManifest.xml синхронизирован.
• Сохранены AES-256-GCM загрузка, нативный Android-мост, разрешения, ресурсы, настройки подписи и формат проектов .optic v17.
• APK в рамках упаковки не собирался; архив содержит проект Android Studio для самостоятельной сборки.

Изменения v23.51:
• Удалены дублирующие номера ОВ на концах соединений и на гребёнках; номера волокон на самих многожильных кабелях сохранены.
• Текстовые подписи маршрутов вынесены в отдельные верхние группы: они остаются поверх оборудования и других линий при смене z-order исходного кабеля; геометрия и нетекстовые overlays следуют слою исходной линии.
• Исправлено начало HTML: удалён ошибочно продублированный 64-символьный SHA-256 перед <!DOCTYPE html>. Хэш паспорта остаётся только в meta-теге; в Chromium проверен режим CSS1Compat.
• В Android assets встроен исправленный standalone HTML v23.51, зашифрованный прежним AES-256-GCM ключом.
• Android versionName/versionCode: 23.51 / 2351. Версия контейнера .optic остаётся 17.
• Сохранены package ID, SDK, нативный мост, разрешения, ресурсы и настройки подписи. APK в рамках упаковки не собирался.

Изменения v23.49–23.50:
• v23.49: подавление стандартного браузерного контекстного меню расширено на интерфейс редактора с сохранением собственных контекстных меню объектов, вкладок и карты; исправлены подписи соединений участков; адаптирована кнопка соединения выбранных волокон; добавлен сброс фиксации усиков после удаления соответствующего соединения; вкладки холста привязаны к фактической области #work.
• v23.50: для визуальных соединений участков (linejoin/bundlejoin) подпись показывает только количество соединённых ОВ и физический метраж (например, «4 ОВ · 100 м»). Названия подключённых концов и стрелки не отображаются. Обычные линии и их подписи не изменялись.
• В app/src/main/assets/app.enc помещён standalone HTML v23.50, зашифрованный AES-256-GCM с прежним ключом Android-оболочки.
• Android versionName/versionCode: 23.50 / 2350. Версия контейнера .optic остаётся 17.
• AndroidManifest.xml комментарий синхронизирован с Gradle metadata.

ОПТИКСХЕМА v23.51 — проект Android Studio

Идентификаторы приложения:
• Название: ОптикСхема (OpticShema)
• Application ID / имя пакета: ru.opticshema.app
• Версия: 23.51 (versionCode 2351)
• Минимальный Android: 6.0 (API 23)
• Target SDK: 34

Последнее обновление v23.51:
• В app/src/main/assets/app.enc встроен standalone HTML v23.48: оптимизирована процедура удаления объектов и связанных соединений.
• Временно скрыта секция «Отображение холста» (резерв, подписи трасс и настройки холста); код контроллеров сохранён.
• Удалены команда «Таблица сварок FiberQ» и её старый ввод JSON. Старые data-fiberq-splice-table записи в проектах .optic v17 сохраняются и читаются планировщиком как исходные данные.
• Android versionName/versionCode: 23.48 / 2348. Версия контейнера .optic остаётся 17.
• AndroidManifest.xml не задаёт версию самостоятельно: значения берутся из app/build.gradle defaultConfig.



Изменения v23.48:
• Унифицировано формирование пользовательских названий процентных делителей: подписи подключённых жил используют название объекта вместо принудительного TV/PON-шаблона.
• В подписи жил сохраняется суффикс фактического выхода (OUT…); идентификаторы выходов и процентное распределение не переименовываются.
• Изменение применяется к оптическим и ТВ-процентным делителям, в том числе с равными и неравными долями; механизм пользовательского имени взят по образцу обычного синего сплиттера.
• Android versionName/versionCode: 23.48 / 2348. Контейнер проекта .optic остаётся v17.
• По запросу пользователя отдельное тестирование этой правки не запускалось.

Сборка APK:
1. Распакуйте ZIP и откройте папку проекта в Android Studio.
2. Дождитесь синхронизации Gradle; нужны JDK 17, Android SDK Platform 35 и Gradle 8.9.
3. Для тестовой сборки: Build → Build Bundle(s) / APK(s) → Build APK(s). Получится debug APK, подписанный локальным Android debug keystore.
4. Для Release используйте свой keystore через локальный release-signing.properties. Эти файлы в архив не включены. Без них Release APK будет unsigned.

ВАЖНО О ПОДПИСИ И ОБНОВЛЕНИИ:
• Для установки поверх уже установленной версии Android требует тот же сертификат подписи.
• Не удаляйте старую версию и не очищайте данные, пока не проверили совпадение сертификатов и не сделали экспорт важных проектов.
• Не публикуйте JKS, пароли и release-signing.properties.

Изменения v23.01:
• В контекстное меню добавлено точечное переименование текстовых надписей схемы, включая подписи направлений кабелей.
• Пользовательские подписи сохраняются в данных объектов и восстанавливаются после обновления визуализации.
• Версия HTML, отображаемая версия редактора и Android versionName синхронизированы: 23.14.

Предыдущий выпуск — v23.00:
• Восстановлено автосохранение основной схемы в отдельном IndexedDB-хранилище.
• При повторном запуске редактор автоматически восстанавливает последнюю сохранённую схему.
• Автосохранение выполняется после действий редактирования, а также при уходе приложения в фон и закрытии WebView.
• Удалён флаг чистого запуска, который блокировал восстановление черновика карты.
• Добавлена общая функция __opticFlushDrafts(), вызываемая Android-оболочкой при переходе приложения в фон.
• Обычное сохранение и экспорт проектов .optic не заменяются и не изменяются.

Проверка:
• Синтаксис всех встроенных JavaScript-блоков проверен Node.js --check.
• Проверена расшифровка и повторное шифрование app.enc.
• Полноценная сборка APK и проверка на Android-устройстве в этой среде не выполнялись.


Дополнение v23.02 — синхронизация имени кабеля и подписей ветвей:
• При переименовании главной надписи кабельного пучка через контекстное меню синхронизируются имя кабеля и метаданные отображения.
• Автоматические подписи связанных кабельных линий обновляются после переименования.
• В старых проектах пользовательская надпись на кабеле теперь учитывается при формировании сокращённых подписей ветвей, даже если data-label содержит тип кабеля.
• Ручные подписи отдельных линий сохраняются; геометрия маршрутов, порты, топология и оптические расчёты не меняются.


Изменения v23.14 — плавное масштабирование и полные подписи кабелей:
• При увеличении/уменьшении холста обновление экранных подписей длины кабеля и измерений откладывается до завершения серии событий масштаба; промежуточная трансформация холста остаётся немедленной.
• Временный облегчённый режим SVG применяется на время серии zoom-событий и снимается после паузы.
• Обновление подписей GPON-ветвей не запускается при отпускании кнопок панели масштаба; оно остаётся включённым после действий непосредственно на холсте и явного запроса перестройки.
• Названия многожильных кабелей сохраняются и отображаются полностью, без принудительного сокращения до многоточия; текст может выходить за границы прямоугольника кабеля.
• Нативный Android GPS-мост, разрешения геолокации, MainActivity.kt и AndroidManifest.xml сохранены без изменений.
• Android versionName обновлён до 23.14, versionCode — до 2314.


Изменения v23.30–v23.32:
• v23.30: оптимизировано отображение сетки во время панорамирования/масштабирования; на дальнем обзоре используется более редкая основная сетка с сохранением исходного шага привязки.
• v23.31: добавлялась контрастная рамка холста; в v23.32 рамка, тень и угловые маркеры удалены по результатам визуальной проверки на Android.
• v23.32: холст отделяется от окружающей рабочей области только цветом. В светлой теме — белая поверхность на сером фоне; в тёмной — графитовая поверхность на более тёмном фоне.
• Геометрия холста, сеточная привязка, структура объектов, топология, расчёты и формат проектов .optic v17 не менялись в этих визуальных обновлениях.
