package ru.opticshema.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Download selected Yandex Tiles API rasters independently of WebView visibility.
 * Tiles are staged in private app storage. For PNG jobs a bounded native
 * PNG encoder writes completed tile rows directly into a private .png file
 * during the download (no WebView PNG recomposition on return). Cache jobs
 * still import staged tiles to the existing IndexedDB when the map is reopened.
 * Only one region job at a time; no tile API keys enter notifications or logs.
 */
class MapAreaDownloadService : Service() {
    companion object {
        private const val PREFS = "optic_area_transfer_2391"
        private const val JOB = "job"
        private const val CHANNEL_ID = "optic_area_background_tiles"
        private const val NOTIFICATION_ID = 2391
        const val START = "ru.opticshema.app.TILE_START"
        const val PAUSE = "ru.opticshema.app.TILE_PAUSE"
        const val RESUME = "ru.opticshema.app.TILE_RESUME"
        const val CANCEL = "ru.opticshema.app.TILE_CANCEL"

        fun jobFolder(context: Context, id: String): File = File(context.filesDir, "optic_area_downloads/$id")
        fun tileFile(context: Context, id: String, z: Int, rawX: Long, y: Long, quality: Int): File =
            File(jobFolder(context, id), "${z}/${rawX}_${y}_${quality}.tile")
        fun pngFile(context: Context, id: String): File = File(jobFolder(context,id),"region.png")
        fun isJobPng(context:Context,file:File):Boolean = try {
            file.name=="region.png" && file.parentFile?.parentFile?.canonicalFile == File(context.filesDir,"optic_area_downloads").canonicalFile
        } catch (_:Exception){false}

        @Synchronized
        fun snapshot(context: Context, includeKey: Boolean = false): JSONObject {
            val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(JOB, null)
            val json = try { JSONObject(raw ?: "{}") } catch (_: Exception) { JSONObject() }
            if (!includeKey) json.remove("apikey")
            return json
        }

        @Synchronized
        private fun store(context: Context, job: JSONObject) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(JOB, job.toString()).commit()
        }

        fun begin(context: Context, json: String): String {
            return try {
                val input = JSONObject(json)
                val key = input.optString("apikey")
                val levels = input.optJSONArray("levels") ?: throw IllegalArgumentException("Нет списка масштабов")
                if (key.isBlank() || levels.length() == 0) throw IllegalArgumentException("Нет ключа API или масштабов")
                var total = 0L
                for (i in 0 until levels.length()) {
                    val l = levels.getJSONObject(i)
                    val z = l.getInt("z")
                    val x0 = l.getLong("x0"); val x1 = l.getLong("x1")
                    val y0 = l.getLong("y0"); val y1 = l.getLong("y1")
                    if (z !in 0..20 || x0 > x1 || y0 > y1 || y0 < 0 || y1 >= (1L shl z))
                        throw IllegalArgumentException("Некорректные координаты тайлов")
                    val count = Math.multiplyExact(x1-x0+1, y1-y0+1)
                    total = Math.addExact(total, count)
                }
                if (total < 1 || total > Int.MAX_VALUE) throw IllegalArgumentException("Невозможно обработать число тайлов")
                var existing = snapshot(context, true)
                val age = System.currentTimeMillis() - existing.optLong("createdAt", System.currentTimeMillis())
                if (age > 30L*24*60*60*1000) {
                    jobFolder(context, existing.optString("id")).deleteRecursively()
                    store(context, JSONObject())
                    existing = JSONObject()
                }
                if (existing.optString("state") in listOf("RUNNING", "PAUSED", "OFFLINE", "DONE", "ERROR"))
                    return JSONObject().put("ok", false).put("error", "Уже выполняется другая загрузка").toString()
                val id = System.currentTimeMillis().toString()
                val job = JSONObject(input.toString())
                val overlayToken = input.optString("overlayToken", "")
                job.remove("overlayToken")
                if (input.optJSONObject("png")?.optBoolean("objects", false) == true) {
                    require(overlayToken.matches(Regex("[0-9a-f-]{36}"))) { "Нет подготовленного слоя объектов" }
                    val source = File(context.filesDir, "optic_png_overlay_staging/$overlayToken")
                    val folder = jobFolder(context, id)
                    require(source.isDirectory && folder.mkdirs() && source.renameTo(File(folder, "overlay"))) { "Не удалось сохранить слой объектов для фоновой загрузки" }
                }
                job.put("id", id)
                job.put("total", total)
                job.put("done", 0)
                job.put("downloaded", 0)
                job.put("pngRows", 0)
                job.put("pngReady", false)
                job.put("state", "RUNNING")
                job.put("message", "Подготовка загрузки")
                job.put("createdAt", System.currentTimeMillis())
                job.put("updatedAt", System.currentTimeMillis())
                store(context, job)
                val intent = Intent(context, MapAreaDownloadService::class.java).setAction(START)
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
                JSONObject().put("ok", true).put("id", id).toString()
            } catch (e: Exception) {
                JSONObject().put("ok", false).put("error", e.message ?: "Не удалось создать задачу Android").toString()
            }
        }

        fun action(context: Context, command: String): Boolean {
            val action = when(command) { "pause" -> PAUSE; "resume" -> RESUME; "cancel" -> CANCEL; else -> return false }
            return try {
                val intent=Intent(context, MapAreaDownloadService::class.java).setAction(action)
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
                true
            } catch (_: Exception) { false }
        }

        fun clearCompleted(context: Context, id: String) {
            val job = snapshot(context, true)
            if (job.optString("id") != id) return
            if (job.optString("state") in listOf("RUNNING", "PAUSED", "OFFLINE")) return
            jobFolder(context, id).deleteRecursively()
            store(context, JSONObject())
        }
    }

    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var stopped = false
    @Volatile private var manuallyPaused = false
    @Volatile private var busy = false
    private lateinit var nm: NotificationManager
    private var foregroundStarted = false
    private var lastNotify = 0L
    private var lastNotifyState = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Загрузка участков карты", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val cmd = intent?.action ?: START
        val saved = snapshot(this, true)
        val state = saved.optString("state")
        // startForeground must be prompt even if invoked from a notification action.
        try { showNotification(saved, state) } catch (_: Exception) { stopSelf(); return START_NOT_STICKY }
        when (cmd) {
            PAUSE -> {
                manuallyPaused = true
                updateState("PAUSED", "Пауза пользователя")
            }
            RESUME -> {
                manuallyPaused = false
                stopped = false
                updateState("RUNNING", "Продолжение загрузки")
                runJobIfNeeded()
            }
            CANCEL -> {
                stopped = true
                updateState("CANCELLED", "Загрузка остановлена")
                stopForegroundCompat()
                stopSelf()
            }
            else -> {
                manuallyPaused = state == "PAUSED"
                stopped = false
                runJobIfNeeded()
            }
        }
        return START_STICKY
    }

    private fun runJobIfNeeded() {
        if (busy) return
        synchronized(this) { if (busy) return; busy = true }
        worker.execute {
            try { runDownloads() } finally {
                busy = false
                if (!manuallyPaused) {
                    val state = snapshot(this, true).optString("state")
                    if (state in listOf("DONE", "ERROR", "CANCELLED")) {
                        stopForegroundCompat(); stopSelf()
                    }
                }
            }
        }
    }

    private fun updateState(state: String, message: String, done: Long?=null, downloaded: Long?=null, pngRows: Int?=null) {
        val job = snapshot(this, true)
        if (!job.has("id")) return
        job.put("state", state)
        job.put("message", message.take(180))
        if (done != null) job.put("done", done)
        if (downloaded != null) job.put("downloaded", downloaded)
        if (pngRows != null) job.put("pngRows", pngRows)
        job.put("updatedAt", System.currentTimeMillis())
        store(this, job)
        showNotification(job, state)
    }

    private fun online(): Boolean {
        val c = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return if (Build.VERSION.SDK_INT >= 23) {
            val network = c.activeNetwork ?: return false
            val caps = c.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } else {
            @Suppress("DEPRECATION")
            val info = c.activeNetworkInfo
            @Suppress("DEPRECATION")
            info?.isConnected == true
        }
    }

    private fun waitBeforeNext(): Boolean {
        while (!stopped) {
            if (manuallyPaused) {
                if (snapshot(this, true).optString("state") != "PAUSED") updateState("PAUSED", "Пауза пользователя")
            } else if (!online()) {
                if (snapshot(this, true).optString("state") != "OFFLINE") updateState("OFFLINE", "Нет интернета — ожидаю подключения")
            } else {
                if (snapshot(this, true).optString("state") != "RUNNING") updateState("RUNNING", "Загружаю тайлы")
                return true
            }
            Thread.sleep(1200L)
        }
        return false
    }

    private fun downloadFile(key: String, z: Int, wrappedX: Long, y: Long, quality: Int, target: File) {
        val q = arrayOf(
            "x="+wrappedX, "y="+y, "z="+z, "scale="+quality,
            "lang=ru_RU", "l=map", "projection=web_mercator", "maptype=map",
            "apikey=" + URLEncoder.encode(key, "UTF-8")
        ).joinToString("&")
        val url = URL("https://tiles.api-maps.yandex.ru/v1/tiles/?$q")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 15000; readTimeout = 20000; useCaches = false
            instanceFollowRedirects = false
        }
        val temp=File(target.parentFile, target.name+".part")
        try {
            val status = connection.responseCode
            if (status != HttpURLConnection.HTTP_OK) throw IllegalStateException("Tiles API HTTP $status")
            val mime = connection.contentType ?: ""
            if (!mime.startsWith("image/")) throw IllegalStateException("Tiles API вернул не изображение")
            target.parentFile?.mkdirs()
            connection.inputStream.use { input -> temp.outputStream().use { output ->
                val buffer=ByteArray(16*1024);var sum=0L
                while (true) {
                    if (stopped) throw java.io.IOException("Загрузка отменена")
                    val n=input.read(buffer);if(n<0)break
                    output.write(buffer,0,n);sum+=n
                    if (sum>10L*1024*1024) throw IllegalStateException("Слишком большой ответ для одного тайла")
                }
            }}
            if(temp.length()==0L)throw java.io.IOException("Пустой тайл")
            if(!temp.renameTo(target))throw java.io.IOException("Не удалось записать файл тайла")
        } finally { temp.delete();connection.disconnect() }
    }

    private fun runDownloads() {
        val job = snapshot(this, true)
        val id = job.optString("id")
        val key = job.optString("apikey")
        val levels = job.optJSONArray("levels") ?: JSONArray()
        val quality = job.optInt("quality", 1).coerceIn(1, 2)
        val total = job.optLong("total")
        val pngGeometry = if(job.optString("mode")!="cache")job.optJSONObject("png") else null
        if (id.isEmpty() || key.isEmpty() || total<=0) { updateState("ERROR", "Нет сохранённого задания");return }
        if(job.optString("mode")!="cache" && pngGeometry==null){updateState("ERROR","Нет данных для PNG");return}
        var done=0L;var downloaded=0L
        var encoder:MapAreaPngWriter?=null
        try {
            if(pngGeometry!=null) {
                // New stream from scratch: cached native tile files allow recovery on process restart.
                encoder=MapAreaPngWriter(jobFolder(this,id),pngGeometry)
                job.put("pngReady", false)
                job.put("pngRows",0)
                store(this,job)
            }
            for (i in 0 until levels.length()) {
                val level=levels.getJSONObject(i)
                val z=level.getInt("z"); val n=1L shl z
                val x0=level.getLong("x0");val x1=level.getLong("x1")
                val y0=level.getLong("y0");val y1=level.getLong("y1")
                for(y in y0..y1) {
                    for(rawX in x0..x1) {
                        if (!waitBeforeNext()) { updateState("CANCELLED", "Остановлено",done,downloaded);return }
                        val f=tileFile(this,id,z,rawX,y,quality)
                        if(!f.isFile || f.length()==0L) {
                            val wrapped=((rawX % n)+n)%n
                            var ok=false;var httpErrors=0
                            while(!ok&&!stopped) {
                                if(!waitBeforeNext()) { updateState("CANCELLED", "Остановлено",done,downloaded);return }
                                try {
                                    downloadFile(key,z,wrapped,y,quality,f)
                                    downloaded++;ok=true
                                } catch(e: java.io.IOException) {
                                    updateState("OFFLINE", "Ожидание сети / повтор соединения",done,downloaded,encoder?.rowsCompleted)
                                    Thread.sleep(3000L)
                                } catch(e: IllegalStateException) {
                                    httpErrors++
                                    if(httpErrors >= 4)throw e
                                    updateState("OFFLINE", "Ответ сервера: ожидаю и повторяю",done,downloaded,encoder?.rowsCompleted)
                                    Thread.sleep(4000L * httpErrors)
                                }
                            }
                            if(!ok) { updateState("CANCELLED", "Остановлено",done,downloaded);return }
                        }
                        done++
                        if(done%12L==0L || done==total){
                            val pngText=encoder?.let{ " · PNG строк ${it.rowsCompleted}/${it.height}" } ?: ""
                            updateState("RUNNING", "Тайлов $done/$total$pngText",done,downloaded,encoder?.rowsCompleted)
                        }
                        Thread.sleep(55L)
                    }
                    // As soon as this tile row is on disk, compress it into the ONE
                    // final PNG stream. No second pass over all downloaded tiles on return.
                    val e=encoder
                    if(e!=null && pngGeometry!=null && z==e.z && y in pngGeometry.getLong("minTY")..pngGeometry.getLong("maxTY")) {
                        e.appendDownloadedRow(y,{rawX->tileFile(this,id,z,rawX,y,quality)},{stopped})
                        updateState("RUNNING", "Тайлов $done/$total · PNG строк ${e.rowsCompleted}/${e.height}",done,downloaded,e.rowsCompleted)
                    }
                }
            }
            val e=encoder
            if(!stopped && e!=null){
                e.finish();encoder=null
                val saved=snapshot(this,true)
                if(saved.optString("id")==id){saved.put("pngReady",true);saved.put("pngRows",e.height);store(this,saved)}
            }
            if(!stopped)updateState("DONE",if(e!=null)"PNG сформирован. Файл готов к сохранению" else "Тайлы готовы: $done из $total",done,downloaded,e?.height)
        }catch(e:Exception) {
            if(stopped)updateState("CANCELLED", "Остановлено",done,downloaded,encoder?.rowsCompleted)
            else updateState("ERROR", (e.message ?: "Ошибка загрузки тайлов"),done,downloaded,encoder?.rowsCompleted)
        }finally {
            encoder?.abort()
        }
    }

    private fun showNotification(job: JSONObject, state: String) {
        val total=job.optLong("total",1).coerceAtLeast(1)
        val done=job.optLong("done",0).coerceAtLeast(0)
        val title=when(state){"PAUSED"->"ОптикСхема · пауза";"OFFLINE"->"ОптикСхема · ожидание сети";"DONE"->"ОптикСхема · сохранение готово";"ERROR"->"ОптикСхема · ошибка";else->"ОптикСхема · загрузка карты"}
        val b= if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,CHANNEL_ID) else Notification.Builder(this)
        val click=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java).apply { flags=Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP },PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText("${done}/${total} · ${job.optString("message").take(70)}")
            .setOngoing(state in listOf("RUNNING","PAUSED","OFFLINE")).setContentIntent(click).setOnlyAlertOnce(true)
            .setProgress(100,((done*100)/total).toInt().coerceIn(0,100),false)
        if(state in listOf("RUNNING","PAUSED","OFFLINE")) {
            val command=if(state=="PAUSED")RESUME else PAUSE
            val label=if(state=="PAUSED")"Продолжить" else "Пауза"
            val pause=PendingIntent.getService(this,1,Intent(this,MapAreaDownloadService::class.java).setAction(command),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val cancel=PendingIntent.getService(this,2,Intent(this,MapAreaDownloadService::class.java).setAction(CANCEL),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            b.addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause,label,pause).build())
            b.addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"Остановить",cancel).build())
        }
        val notification=b.build()
        if (!foregroundStarted) {
            if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION_ID,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(NOTIFICATION_ID,notification)
            foregroundStarted=true
            lastNotify=System.currentTimeMillis();lastNotifyState=state
        } else if (state != lastNotifyState || System.currentTimeMillis()-lastNotify > 1300L || state=="DONE") {
            try { nm.notify(NOTIFICATION_ID,notification) } catch (_: SecurityException) { }
            lastNotify=System.currentTimeMillis();lastNotifyState=state
        }
    }

    private fun stopForegroundCompat() {
        if(Build.VERSION.SDK_INT>=24) stopForeground(STOP_FOREGROUND_REMOVE)
        else { @Suppress("DEPRECATION") stopForeground(true) }
        foregroundStarted=false
    }

    override fun onDestroy() {
        stopped=true
        worker.shutdownNow()
        super.onDestroy()
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        stopped=true
        updateState("PAUSED", "Android ограничил время фоновой службы; открой приложение")
        stopForegroundCompat()
        stopSelf()
    }
}
