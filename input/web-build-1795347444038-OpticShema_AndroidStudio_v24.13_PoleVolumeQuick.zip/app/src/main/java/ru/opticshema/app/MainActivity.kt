package ru.opticshema.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.KeyEvent
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebResourceError
import android.webkit.RenderProcessGoneDetail
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.util.Log
import java.io.FileInputStream
import android.webkit.ValueCallback
import android.net.Uri
import android.content.Intent
import android.provider.OpenableColumns
import java.io.File
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.io.IOException
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class MainActivity : Activity() {
    private lateinit var web: WebView
    // v23.94: native WebView renderer may die without killing this Activity.
    // A terminated WebView must NEVER be reused. The editor is restored by
    // creating a fresh WebView and loading our embedded HTML, not web.reload().
    private var editorWebViewAlive = false
    private var rendererRecoveryPending = false
    private var activityForeground = false
    private val rendererFailureTimes = mutableListOf<Long>()
    private var localMainFrameRetryUsed = false
    private val recoveryTag = "OpticShemaWebView"
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val key = hexToBytes("065fa03008020775cbb811df1b4b186cf4e650352f650f07a3e68c07eeb91140")
    private val pickFile = 8012
    private val saveFileRequest = 8013
    private val gpsPermissionRequest = 8014
    private var pendingGpsRequest = false
    private var pendingGpsWatchRequest = false
    @Volatile private var gpsWatchRequested = false
    @Volatile private var poleVolumeShortcutActive = false
    private var lastPoleVolumePlacementAt = 0L
    private var gpsWatchManager: LocationManager? = null
    private val gpsWatchListeners = mutableListOf<LocationListener>()
    private var gpsWatchHasFix = false
    private var gpsWatchBestFix: Location? = null
    private var gpsWatchSequence = 0
    @Volatile private var pendingSaveBytes: ByteArray? = null
    @Volatile private var pendingSaveDiskFile: File? = null
    private var streamSaveFile: File? = null
    private var streamSaveOutput: java.io.FileOutputStream? = null
    private var expectedStreamBytes: Long = -1L
    private var receivedStreamBytes: Long = 0L
    private val tileHttpPool = Executors.newFixedThreadPool(3)
    private val saveBufferLock = Any()
    private var saveBuffer: ByteArrayOutputStream? = null
    private var saveFileName: String = "OpticShema-export"
    private var saveMimeType: String = "application/octet-stream"
    private var expectedBase64Length: Int = -1
    private var receivedBase64Length: Int = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemUI()
        web = createEditorWebView()
        editorWebViewAlive = true
        setContentView(web)
        @Suppress("DEPRECATION")
        window.decorView.setOnSystemUiVisibilityChangeListener { visibility ->
            val required = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            if ((visibility and required) != required) hideSystemUI()
        }
        loadEncryptedEditor(web)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createEditorWebView(): WebView {
        val target = WebView(this)
        target.setBackgroundColor(android.graphics.Color.rgb(16,23,32))
        target.settings.javaScriptEnabled = true
        target.settings.domStorageEnabled = true
        target.settings.setGeolocationEnabled(true)
        target.settings.allowFileAccess = true
        target.settings.allowContentAccess = true
        target.settings.allowFileAccessFromFileURLs = false
        target.settings.allowUniversalAccessFromFileURLs = false
        target.settings.setSupportZoom(false)
        target.settings.builtInZoomControls = false
        target.settings.displayZoomControls = false
        WebView.setWebContentsDebuggingEnabled(false)
        // Native background tile files are exposed to the existing WebView without
        // copying thousands of bitmaps through a JavaScript/base64 bridge.
        target.webViewClient = object : WebViewClient() {
            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                return handleEditorRendererGone(view, detail)
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                super.onReceivedError(view, request, error)
                // Only the local DOCUMENT can cause a recoverable page error.
                // Individual Yandex/OSM raster or network requests are not a page failure.
                if (!request.isForMainFrame || view !== web || !editorWebViewAlive ||
                    request.url.host != "appassets.androidplatform.net") return
                Log.e(recoveryTag, "Local editor main-frame error: " + error.errorCode + " " + error.description)
                if (localMainFrameRetryUsed) {
                    showEditorRecoveryScreen("Внутренняя страница не открылась. Данные проекта остаются в хранилище.")
                    return
                }
                localMainFrameRetryUsed = true
                view.post { if (view === web && editorWebViewAlive) loadEncryptedEditor(view) }
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return null
                if (uri.scheme != "https" || uri.host != "appassets.androidplatform.net" ||
                    !uri.path.orEmpty().startsWith("/optic-area-tile/")) return null
                val items = uri.pathSegments
                if (items.size != 7 || items[0] != "optic-area-tile") return missingAreaTile()
                val jobId = items[1]
                val z = items[2].toIntOrNull(); val x = items[3].toLongOrNull()
                val y = items[4].toLongOrNull(); val quality = items[5].toIntOrNull()
                // The trailing marker is intentionally fixed so no paths can be requested.
                if (items[6] != "raster" || jobId != MapAreaDownloadService.snapshot(this@MainActivity).optString("id") ||
                    z == null || x == null || y == null || quality == null || z !in 0..20 || quality !in 1..2)
                    return missingAreaTile()
                return try {
                    val file = MapAreaDownloadService.tileFile(this@MainActivity, jobId, z, x, y, quality)
                    if (!file.isFile || file.length() == 0L) missingAreaTile()
                    else WebResourceResponse("image/png", null, FileInputStream(file)).apply {
                        setStatusCodeAndReasonPhrase(200, "OK")
                        responseHeaders = mapOf("Cache-Control" to "no-store")
                    }
                } catch (_: Exception) { missingAreaTile() }
            }
        }
        target.addJavascriptInterface(OpticFileBridge(), "OpticFileBridge")
        target.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivityForResult(intent, pickFile)
                    true
                } catch (e: Exception) {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = null
                    false
                }
            }
        }
        return target
    }

    private fun loadEncryptedEditor(target: WebView) {
        try {
            val packed = assets.open("app.enc").use { it.readBytes() }
            val nonce = packed.copyOfRange(0, 12)
            val cipherText = packed.copyOfRange(12, packed.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            val page = cipher.doFinal(cipherText).toString(Charsets.UTF_8)
            // Preserve the exact origin so the existing IndexedDB and cache survive.
            target.loadDataWithBaseURL("https://appassets.androidplatform.net/", page, "text/html", "UTF-8", null)
        } catch (e: Exception) {
            Log.e(recoveryTag, "Embedded HTML could not be loaded", e)
            showEditorRecoveryScreen("Ошибка открытия встроенного HTML: " + (e.message ?: "неизвестная ошибка"))
        }
    }

    private fun handleEditorRendererGone(dead: WebView, detail: RenderProcessGoneDetail): Boolean {
        Log.w(recoveryTag, "WebView renderer terminated: didCrash=" + detail.didCrash())
        if (!::web.isInitialized || dead !== web) {
            try { (dead.parent as? ViewGroup)?.removeView(dead) } catch (_: Exception) { }
            try { dead.destroy() } catch (_: Exception) { }
            return true
        }
        editorWebViewAlive = false
        poleVolumeShortcutActive = false
        rendererRecoveryPending = true
        localMainFrameRetryUsed = false
        // A pending file picker may refer to this defunct renderer.
        try { fileCallback?.onReceiveValue(null) } catch (_: Exception) { }
        fileCallback = null
        try { (dead.parent as? ViewGroup)?.removeView(dead) } catch (_: Exception) { }
        try { dead.destroy() } catch (e: Exception) { Log.w(recoveryTag, "WebView destroy failed", e) }
        // Defer recovery until foreground if Android reclaimed the renderer in background.
        if (activityForeground) window.decorView.post { restoreEditorIfNeeded() }
        return true
    }

    private fun restoreEditorIfNeeded() {
        if (!rendererRecoveryPending || isFinishing || isDestroyed) return
        val now = android.os.SystemClock.elapsedRealtime()
        rendererFailureTimes.removeAll { now - it > 60_000L }
        if (rendererFailureTimes.size >= 3) {
            rendererRecoveryPending = false
            showEditorRecoveryScreen("WebView завершался несколько раз подряд. Повторное открытие временно остановлено.")
            return
        }
        rendererFailureTimes.add(now)
        try {
            val fresh = createEditorWebView()
            web = fresh
            editorWebViewAlive = true
            rendererRecoveryPending = false
            localMainFrameRetryUsed = false
            setContentView(fresh)
            hideSystemUI()
            loadEncryptedEditor(fresh)
            Log.i(recoveryTag, "Fresh WebView created for embedded editor recovery")
        } catch (e: Exception) {
            Log.e(recoveryTag, "WebView reinitialization failed", e)
            rendererRecoveryPending = false
            editorWebViewAlive = false
            showEditorRecoveryScreen("Не удалось восстановить WebView: " + (e.message ?: "неизвестная ошибка"))
        }
    }

    private fun showEditorRecoveryScreen(message: String) {
        poleVolumeShortcutActive = false
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(35, 55, 35, 35)
            setBackgroundColor(android.graphics.Color.rgb(16, 23, 32))
        }
        box.addView(TextView(this).apply {
            text = "ОптикСхема: страница редактора недоступна.\n\n" + message +
                "\n\nПроекты и загруженные тайлы не удалялись."
            textSize = 17f
            setTextColor(android.graphics.Color.WHITE)
        })
        box.addView(Button(this).apply {
            text = "Перезапустить редактор"
            setOnClickListener {
                rendererFailureTimes.clear()
                rendererRecoveryPending = true
                // If renderer is alive (main-frame error), destroy it before creating another.
                if (editorWebViewAlive && ::web.isInitialized) {
                    try { (web.parent as? ViewGroup)?.removeView(web) } catch (_: Exception) { }
                    try { web.destroy() } catch (_: Exception) { }
                    editorWebViewAlive = false
                }
                restoreEditorIfNeeded()
            }
        })
        setContentView(box)
        hideSystemUI()
    }

    private fun evaluateEditorJs(code: String, callback: ValueCallback<String>? = null) {
        if (!::web.isInitialized || !editorWebViewAlive) return
        try { web.evaluateJavascript(code, callback) }
        catch (e: Exception) { Log.w(recoveryTag, "WebView JavaScript callback skipped during renderer recovery", e) }
    }

    private fun missingAreaTile(): WebResourceResponse {
        return WebResourceResponse("text/plain", "UTF-8", "Missing tile".byteInputStream()).apply {
            setStatusCodeAndReasonPhrase(404, "Not Found")
            responseHeaders = mapOf("Cache-Control" to "no-store")
        }
    }

    private fun sendGpsLocation(location: Location) {
        val lat = location.latitude
        val lon = location.longitude
        val accuracy = if (location.accuracy > 0f) location.accuracy.toDouble() else 0.0
        val bearing = if (location.hasBearing()) location.bearing.toDouble().toString() else "null"
        val speed = if (location.hasSpeed()) location.speed.toDouble().toString() else "null"
        val timestamp = if (location.time > 0L) location.time else System.currentTimeMillis()
        evaluateEditorJs(
            "window.__opticNativeGpsResult && window.__opticNativeGpsResult($lat,$lon,$accuracy,$bearing,$speed,$timestamp)",
            null
        )
    }

    private fun startNativeGpsRequest() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (!fine && !coarse) {
                pendingGpsRequest = true
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), gpsPermissionRequest)
                return
            }
        }
        requestNativeLocation()
    }

    @SuppressLint("MissingPermission")
    private fun requestNativeLocation() {
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        val hasFine = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) {
            sendGpsError("Разрешение на местоположение не предоставлено.")
            return
        }
        val providers = availableGpsProviders(manager, hasFine, hasCoarse)
        val provider = providers.firstOrNull()
        if (provider == null) {
            sendGpsError("Включи геолокацию в настройках Android.")
            return
        }
        try {
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    try { manager.removeUpdates(this) } catch (_: Exception) { }
                    sendGpsLocation(location)
                }
                @Deprecated("Deprecated by Android")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }
                override fun onProviderEnabled(provider: String) { }
                override fun onProviderDisabled(provider: String) { }
            }
            manager.requestSingleUpdate(provider, listener, Looper.getMainLooper())
            manager.getLastKnownLocation(provider)?.let { cached ->
                if (System.currentTimeMillis() - cached.time < 120_000L) {
                    try { manager.removeUpdates(listener) } catch (_: Exception) { }
                    sendGpsLocation(cached)
                }
            }
        } catch (e: Exception) {
            sendGpsError(e.message ?: "Не удалось получить координаты Android.")
        }
    }


    private fun startNativeGpsWatch() {
        gpsWatchRequested = true
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (!fine && !coarse) {
                pendingGpsWatchRequest = true
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), gpsPermissionRequest)
                return
            }
        }
        requestNativeLocationUpdates()
    }

    /** Prefer the system fused location on Android 12+, while keeping network and GNSS
     * subscriptions in parallel. Satellites may take minutes to acquire indoors, while
     * network has a recent (possibly less accurate) fix. HTML keeps the existing accuracy
     * check and asks for confirmation if a pole is placed with accuracy worse than 30 m. */
    private fun availableGpsProviders(manager: LocationManager, hasFine: Boolean, hasCoarse: Boolean): List<String> {
        val providers = mutableListOf<String>()
        fun enabled(provider: String): Boolean = try { manager.isProviderEnabled(provider) } catch (_: Exception) { false }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S && (hasFine || hasCoarse) &&
            enabled(LocationManager.FUSED_PROVIDER)) providers.add(LocationManager.FUSED_PROVIDER)
        if ((hasFine || hasCoarse) && enabled(LocationManager.NETWORK_PROVIDER)) providers.add(LocationManager.NETWORK_PROVIDER)
        if (hasFine && enabled(LocationManager.GPS_PROVIDER)) providers.add(LocationManager.GPS_PROVIDER)
        return providers.distinct()
    }

    private fun sendGpsStatus(message: String) {
        evaluateEditorJs("window.__opticNativeGpsStatus && window.__opticNativeGpsStatus(" +
            org.json.JSONObject.quote(message) + ")", null)
    }

    @SuppressLint("MissingPermission")
    private fun requestNativeLocationUpdates() {
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        val hasFine = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) {
            sendGpsError("Разрешение на местоположение не предоставлено.")
            return
        }
        val providers = availableGpsProviders(manager, hasFine, hasCoarse)
        if (providers.isEmpty()) {
            sendGpsError("В Android отключены доступные источники геолокации. Включи системную геолокацию и точность определения.")
            return
        }
        stopNativeGpsListenerOnly()
        gpsWatchHasFix = false
        gpsWatchBestFix = null
        val sequence = ++gpsWatchSequence
        var lastError: String? = null
        for (provider in providers) {
            try {
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        if (!gpsWatchRequested || sequence != gpsWatchSequence) return
                        // A fresh satellite fix must not be replaced by a worse network fix.
                        val old = gpsWatchBestFix
                        val fresh = location.time > 0L && System.currentTimeMillis() - location.time in 0L..20_000L
                        val goodEnough = old == null ||
                            System.currentTimeMillis() - old.time > 15_000L ||
                            (location.hasAccuracy() && (!old.hasAccuracy() || location.accuracy <= old.accuracy * 1.5f))
                        if (!fresh || !goodEnough) return
                        gpsWatchBestFix = location
                        gpsWatchHasFix = true
                        sendGpsLocation(location)
                    }
                    @Deprecated("Deprecated by Android")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }
                    override fun onProviderEnabled(provider: String) { }
                    override fun onProviderDisabled(provider: String) { }
                }
                manager.requestLocationUpdates(provider, 1500L, 1f, listener, Looper.getMainLooper())
                gpsWatchListeners.add(listener)
            } catch (e: Exception) {
                lastError = e.message ?: "Ошибка GPS-провайдера"
                Log.w(recoveryTag, "Location provider registration failed: $provider", e)
            }
        }
        if (gpsWatchListeners.isEmpty()) {
            sendGpsError("Не удалось включить GPS: " + (lastError ?: "нет доступных провайдеров"))
            return
        }
        gpsWatchManager = manager
        // Forward only recent cached positions; do not disguise stale locations as new.
        val now = System.currentTimeMillis()
        val recent = providers.mapNotNull { provider ->
            try { manager.getLastKnownLocation(provider)?.takeIf { it.time > 0L &&
                now - it.time in 0L..20_000L } } catch (_: Exception) { null }
        }
        if (recent.isNotEmpty()) {
            val best = recent.minWithOrNull(compareBy<Location> { if (it.hasAccuracy()) it.accuracy else 10000f }
                .thenByDescending { it.time })
            if (best != null) {
                gpsWatchBestFix = best
                gpsWatchHasFix = true
                sendGpsLocation(best)
            }
        }
        if (!gpsWatchHasFix) {
            sendGpsStatus("GPS: ищу координаты (сеть и спутники)…")
            web.postDelayed({
                if (gpsWatchRequested && sequence == gpsWatchSequence && !gpsWatchHasFix)
                    sendGpsStatus("GPS пока не дал точку. Включи точное местоположение и попробуй на открытом месте.")
            }, 12_000L)
        }
    }

    private fun stopNativeGpsListenerOnly() {
        val manager = gpsWatchManager
        if (manager != null) for (listener in gpsWatchListeners) {
            try { manager.removeUpdates(listener) } catch (_: Exception) { }
        }
        gpsWatchListeners.clear()
        gpsWatchManager = null
        gpsWatchBestFix = null
        gpsWatchSequence++
    }

    private fun stopNativeGpsWatch() {
        gpsWatchRequested = false
        pendingGpsWatchRequest = false
        stopNativeGpsListenerOnly()
    }

    private fun sendGpsError(message: String) {
        evaluateEditorJs("window.__opticNativeGpsError && window.__opticNativeGpsError(" + org.json.JSONObject.quote(message) + ")", null)
    }

    @Deprecated("Deprecated by Android")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == gpsPermissionRequest) {
            pendingGpsRequest = false
            val wasWatchRequest = pendingGpsWatchRequest
            pendingGpsWatchRequest = false
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
                if (wasWatchRequest) requestNativeLocationUpdates() else requestNativeLocation()
            } else {
                gpsWatchRequested = false
                sendGpsError("Доступ к местоположению запрещён. Разреши GPS в настройках приложения.")
            }
        }
    }

    private fun hideSystemUI() {
        val decor = window.decorView
        decor.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    override fun onPause() {
        activityForeground = false
        // Avoid keeping GPS active while the app is backgrounded; resume the watch when foregrounded.
        if (gpsWatchRequested) stopNativeGpsListenerOnly()
        // Flush the schematic and map drafts to IndexedDB before the WebView is backgrounded.
        if (::web.isInitialized && editorWebViewAlive) {
            try {
                evaluateEditorJs("window.__opticFlushDrafts && window.__opticFlushDrafts().catch(function(e){console.warn('Draft flush failed',e)})", null)
            } catch (_: Exception) { }
        }
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onResume() {
        super.onResume()
        activityForeground = true
        hideSystemUI()
        restoreEditorIfNeeded()
        if (gpsWatchRequested) requestNativeLocationUpdates()
        if (::web.isInitialized && editorWebViewAlive) {
            web.post { if (editorWebViewAlive) evaluateEditorJs("window.__opticAreaAppResumed && window.__opticAreaAppResumed()", null) }
        }
    }
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP && poleVolumeShortcutActive && activityForeground && editorWebViewAlive) {
            // One pole per deliberate press; never place another from key auto-repeat.
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                val now = android.os.SystemClock.elapsedRealtime()
                if (now - lastPoleVolumePlacementAt >= 650L) {
                    lastPoleVolumePlacementAt = now
                    evaluateEditorJs("window.__opticNativePoleVolumeQuick && window.__opticNativePoleVolumeQuick()", null)
                }
            }
            return true // Consume both DOWN and UP only while the pole tool is active.
        }
        return super.dispatchKeyEvent(event)
    }
    override fun onBackPressed() { if (::web.isInitialized && editorWebViewAlive && web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode == pickFile) {
            var webViewUris: Array<Uri>? = null
            if (resultCode == RESULT_OK && data != null) {
                val selectedUri = data.data
                    ?: data.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
                if (selectedUri != null) {
                    try {
                        // Do not let WebView read an arbitrary provider URI directly.
                        // Read it through Android ContentResolver and hand WebView a local copy.
                        var displayName = "OpticShema-project.optic"
                        try {
                            contentResolver.query(selectedUri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                                if (cursor.moveToFirst()) {
                                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                                    if (index >= 0) displayName = cursor.getString(index) ?: displayName
                                }
                            }
                        } catch (_: Exception) { }

                        val safeName = displayName.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
                            .ifBlank { "OpticShema-project.optic" }
                        val extension = safeName.substringAfterLast('.', "optic").take(12)
                        val importDir = File(cacheDir, "project_import").apply { mkdirs() }
                        importDir.listFiles()?.forEach { old ->
                            if (old.isFile && System.currentTimeMillis() - old.lastModified() > 24L * 60L * 60L * 1000L) old.delete()
                        }
                        val localFile = File.createTempFile("optic_import_", ".$extension", importDir)
                        val input = contentResolver.openInputStream(selectedUri)
                            ?: throw IllegalStateException("Файловый менеджер не открыл выбранный файл")
                        input.use { source ->
                            localFile.outputStream().use { target -> source.copyTo(target) }
                        }
                        if (!localFile.isFile || localFile.length() <= 0L) {
                            localFile.delete()
                            throw IllegalStateException("Android прочитал выбранный файл как пустой")
                        }
                        webViewUris = arrayOf(Uri.fromFile(localFile))
                    } catch (e: Exception) {
                        evaluateEditorJs(
                            "console.error('Ошибка чтения выбранного файла: ' + " +
                                org.json.JSONObject.quote(e.message ?: "неизвестная ошибка") + ")",
                            null
                        )
                        webViewUris = null
                    }
                }
            }
            fileCallback?.onReceiveValue(webViewUris)
            fileCallback = null
        } else if (requestCode == saveFileRequest) {
            val diskFile = pendingSaveDiskFile
            pendingSaveDiskFile = null
            val bytes = pendingSaveBytes
            pendingSaveBytes = null
            val targetUri = data?.data
                ?: data?.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
            if (diskFile != null) {
                if (resultCode == RESULT_OK && targetUri != null && diskFile.isFile) {
                    // Large copy runs off the UI thread. Progress is reported to WebView.
                    tileHttpPool.execute {
                        try {
                            val output = try { contentResolver.openOutputStream(targetUri, "wt") }
                                catch (_: Exception) { null }
                                ?: contentResolver.openOutputStream(targetUri, "w")
                                ?: throw IllegalStateException("Android не открыл запись файла")
                            var copied = 0L
                            var lastPercent = -1
                            output.use { target ->
                                diskFile.inputStream().use { source ->
                                    val buffer = ByteArray(256 * 1024)
                                    while (true) {
                                        val n = source.read(buffer)
                                        if (n < 0) break
                                        target.write(buffer, 0, n)
                                        copied += n
                                        val percent = ((copied * 100.0) / diskFile.length().coerceAtLeast(1L)).toInt().coerceIn(0, 100)
                                        if (percent >= lastPercent + 2 || percent == 100) {
                                            lastPercent = percent
                                            runOnUiThread { evaluateEditorJs("window.__opticNativeSaveProgress && window.__opticNativeSaveProgress(" + percent + ")", null) }
                                        }
                                    }
                                    target.flush()
                                }
                            }
                            runOnUiThread { evaluateEditorJs("window.__opticNativeSaveComplete && window.__opticNativeSaveComplete(true)", null) }
                        } catch (e: Exception) {
                            runOnUiThread { evaluateEditorJs("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось сохранить файл") + ")", null) }
                        } finally {
                            if (!MapAreaDownloadService.isJobPng(this@MainActivity,diskFile)) diskFile.delete()
                        }
                    }
                } else {
                    if (!MapAreaDownloadService.isJobPng(this,diskFile)) diskFile.delete()
                    evaluateEditorJs("window.__opticNativeSaveComplete && window.__opticNativeSaveComplete(false)", null)
                }
            } else if (resultCode == RESULT_OK && targetUri != null && bytes != null) {
                try {
                    // Use the URI returned by the system picker (including a user-renamed name).
                    // Truncate explicitly so provider defaults cannot append to an old document.
                    val output = try {
                        contentResolver.openOutputStream(targetUri, "wt")
                    } catch (_: Exception) {
                        null
                    } ?: contentResolver.openOutputStream(targetUri, "w")
                      ?: throw IllegalStateException("Android не открыл поток записи файла")
                    output.use { stream ->
                        stream.write(bytes)
                        stream.flush()
                    }
                    evaluateEditorJs("window.__opticNativeSaveComplete && window.__opticNativeSaveComplete(true)", null)
                } catch (e: Exception) {
                    evaluateEditorJs("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось сохранить файл") + ")", null)
                }
            } else {
                evaluateEditorJs("window.__opticNativeSaveComplete && window.__opticNativeSaveComplete(false)", null)
            }
        }
    }
    private fun safeExportName(rawName: String): String {
        val leaf = rawName.substringAfterLast('/').substringAfterLast('\\')
        val cleaned = leaf
            .replace(Regex("[\\u0000-\\u001F\\u007F]"), "")
            .replace(Regex("[<>:\"|?*]"), "_")
            .trim()
            .trimEnd('.', ' ')
        return cleaned.ifBlank { "OpticShema-export" }.take(180)
    }

    // v23.83: HTTPS-only native tile transport. Restrict the JS-facing bridge to
    // the official Yandex raster Tiles API; never follow redirects to other hosts.
    private fun downloadYandexTile(requestId: String, rawUrl: String) {
        if (!requestId.matches(Regex("[A-Za-z0-9_-]{1,64}"))) return
        tileHttpPool.execute {
            var connection: HttpURLConnection? = null
            try {
                val uri = Uri.parse(rawUrl)
                if (uri.scheme != "https" || uri.host != "tiles.api-maps.yandex.ru" ||
                    uri.path != "/v1/tiles/" || rawUrl.length > 2048) {
                    throw IOException("Запрещённый адрес тайла")
                }
                val conn = URL(rawUrl).openConnection() as HttpURLConnection
                connection = conn
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 9000
                conn.readTimeout = 13000
                conn.requestMethod = "GET"
                val code = conn.responseCode
                if (code != 200) throw IOException("HTTP $code")
                val mime = conn.contentType ?: ""
                if (!mime.startsWith("image/")) throw IOException("Tiles API вернул не изображение")
                val output = ByteArrayOutputStream()
                conn.inputStream.use { stream ->
                    val chunk = ByteArray(16384)
                    while (true) {
                        val count = stream.read(chunk)
                        if (count < 0) break
                        if (output.size() + count > 1200000) throw IOException("Тайл слишком большой")
                        output.write(chunk, 0, count)
                    }
                }
                val data = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
                runOnUiThread {
                    if (::web.isInitialized) evaluateEditorJs(
                        "window.__opticNativeTileResult && window.__opticNativeTileResult(" +
                        org.json.JSONObject.quote(requestId) + "," +
                        org.json.JSONObject.quote(data) + ",null)", null
                    )
                }
            } catch (error: Exception) {
                // Do not return raw URLs: they contain the API key.
                val safeMessage = (error.message ?: "Не удалось загрузить тайл").replace(
                    Regex("apikey=[^&\\s]+", RegexOption.IGNORE_CASE), "apikey=***"
                )
                runOnUiThread {
                    if (::web.isInitialized) evaluateEditorJs(
                        "window.__opticNativeTileResult && window.__opticNativeTileResult(" +
                        org.json.JSONObject.quote(requestId) + ",null," +
                        org.json.JSONObject.quote(safeMessage) + ")", null
                    )
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private inner class OpticFileBridge {

        @android.webkit.JavascriptInterface
        fun startAreaDownload(payload: String): String {
            val result = MapAreaDownloadService.begin(this@MainActivity, payload)
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread {
                    try { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2391) }
                    catch (_: Exception) { }
                }
            }
            return result
        }

        @android.webkit.JavascriptInterface
        fun areaDownloadExportPng(jobId: String, requestedName: String): Boolean {
            val job=MapAreaDownloadService.snapshot(this@MainActivity)
            if(job.optString("id")!=jobId || job.optString("state")!="DONE" || !job.optBoolean("pngReady",false))return false
            val file=MapAreaDownloadService.pngFile(this@MainActivity,jobId)
            if(!file.isFile || file.length()<=64L)return false
            runOnUiThread {
                try {
                    // Directly copy the native-assembled PNG; the WebView never
                    // imports/recompresses thousands of PNG tiles for this export.
                    pendingSaveDiskFile=file
                    pendingSaveBytes=null
                    val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type="image/png"
                        putExtra(Intent.EXTRA_TITLE,safeExportName(requestedName))
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    }
                    startActivityForResult(intent,saveFileRequest)
                }catch(e:Exception){
                    pendingSaveDiskFile=null
                    evaluateEditorJs("window.__opticNativeSaveError && window.__opticNativeSaveError("+
                        org.json.JSONObject.quote(e.message?:"Не удалось открыть сохранение PNG")+")",null)
                }
            }
            return true
        }

        @android.webkit.JavascriptInterface
        fun areaDownloadStatus(): String = MapAreaDownloadService.snapshot(this@MainActivity).toString()

        @android.webkit.JavascriptInterface
        fun areaDownloadControl(command: String): Boolean = MapAreaDownloadService.action(this@MainActivity, command)

        @android.webkit.JavascriptInterface
        fun areaDownloadFinish(jobId: String) {
            MapAreaDownloadService.clearCompleted(this@MainActivity, jobId)
        }
        @android.webkit.JavascriptInterface
        fun fetchYandexTile(requestId: String, url: String) {
            downloadYandexTile(requestId, url)
        }

        @android.webkit.JavascriptInterface
        fun requestGps() {
            runOnUiThread { startNativeGpsRequest() }
        }

        @android.webkit.JavascriptInterface
        fun setPoleVolumeShortcutActive(active: Boolean) {
            poleVolumeShortcutActive = active
        }

        @android.webkit.JavascriptInterface
        fun startGpsWatch() {
            runOnUiThread { startNativeGpsWatch() }
        }

        @android.webkit.JavascriptInterface
        fun stopGpsWatch() {
            runOnUiThread { stopNativeGpsWatch() }
        }

        // 23.89: disk-backed streaming save for large PNG; no arbitrary total byte cap.
        // Each JS call carries at most 48 KiB of base64, not the entire image.
        @android.webkit.JavascriptInterface
        fun beginSaveBlob(fileName: String, mimeType: String, totalBytes: String): Boolean {
            val expected = totalBytes.toLongOrNull() ?: return false
            if (expected < -1L || (expected == -1L && mimeType != "image/png")) return false
            return try {
                synchronized(saveBufferLock) {
                    try { streamSaveOutput?.close() } catch (_: Exception) { }
                    streamSaveFile?.delete()
                    val nextFile = File.createTempFile("optic_png_export_", ".part", cacheDir)
                    streamSaveFile = nextFile
                    streamSaveOutput = nextFile.outputStream()
                    saveFileName = safeExportName(fileName)
                    saveMimeType = mimeType.ifBlank { "image/png" }
                    expectedStreamBytes = expected
                    receivedStreamBytes = 0L
                }
                true
            } catch (_: Exception) {
                synchronized(saveBufferLock) {
                    try { streamSaveOutput?.close() } catch (_: Exception) { }
                    streamSaveOutput = null
                    streamSaveFile?.delete()
                    streamSaveFile = null
                    expectedStreamBytes = -1L
                    receivedStreamBytes = 0L
                }
                false
            }
        }

        @android.webkit.JavascriptInterface
        fun appendSaveBlobChunk(chunk: String): Boolean {
            if (chunk.length > 48 * 1024) return false
            return try {
                val bytes = Base64.decode(chunk, Base64.NO_WRAP)
                synchronized(saveBufferLock) {
                    val output = streamSaveOutput ?: return false
                    if (expectedStreamBytes < -1L || (expectedStreamBytes >= 0L && receivedStreamBytes > expectedStreamBytes - bytes.size)) return false
                    output.write(bytes)
                    receivedStreamBytes += bytes.size.toLong()
                }
                true
            } catch (_: Exception) { false }
        }

        @android.webkit.JavascriptInterface
        fun cancelSaveBlob() {
            synchronized(saveBufferLock) {
                try { streamSaveOutput?.close() } catch (_: Exception) { }
                streamSaveOutput = null
                streamSaveFile?.delete()
                streamSaveFile = null
                expectedStreamBytes = -1L
                receivedStreamBytes = 0L
            }
        }

        @android.webkit.JavascriptInterface
        fun finishSaveBlob(): Boolean {
            val tmp: File
            val name: String
            val mime: String
            synchronized(saveBufferLock) {
                val output = streamSaveOutput ?: return false
                tmp = streamSaveFile ?: return false
                if (expectedStreamBytes >= 0L && receivedStreamBytes != expectedStreamBytes) return false
                try { output.flush(); output.close() } catch (_: Exception) { return false }
                streamSaveOutput = null
                streamSaveFile = null
                expectedStreamBytes = -1L
                receivedStreamBytes = 0L
                if (tmp.length() <= 0L) { tmp.delete(); return false }
                name = saveFileName
                mime = saveMimeType
            }
            runOnUiThread {
                try {
                    pendingSaveDiskFile?.delete()
                    pendingSaveDiskFile = tmp
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mime
                        putExtra(Intent.EXTRA_TITLE, safeExportName(name))
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    }
                    startActivityForResult(intent, saveFileRequest)
                } catch (e: Exception) {
                    pendingSaveDiskFile = null
                    tmp.delete()
                    evaluateEditorJs("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось открыть сохранение") + ")", null)
                }
            }
            return true
        }

        @android.webkit.JavascriptInterface
        fun beginSaveFile(fileName: String, mimeType: String, totalBase64Length: Int): Boolean {
            if (totalBase64Length < 0 || totalBase64Length > 80 * 1024 * 1024) return false
            return try {
                synchronized(saveBufferLock) {
                    saveBuffer?.reset()
                    saveBuffer = ByteArrayOutputStream()
                    saveFileName = safeExportName(fileName)
                    saveMimeType = mimeType.ifBlank { "application/octet-stream" }
                    expectedBase64Length = totalBase64Length
                    receivedBase64Length = 0
                }
                true
            } catch (_: Exception) {
                synchronized(saveBufferLock) { saveBuffer = null; expectedBase64Length = -1; receivedBase64Length = 0 }
                false
            }
        }

        @android.webkit.JavascriptInterface
        fun appendSaveFileChunk(chunk: String): Boolean {
            return try {
                synchronized(saveBufferLock) {
                    val buffer = saveBuffer ?: return false
                    if (chunk.length > 48 * 1024 || receivedBase64Length + chunk.length > expectedBase64Length) return false
                    buffer.write(Base64.decode(chunk, Base64.DEFAULT))
                    receivedBase64Length += chunk.length
                }
                true
            } catch (_: Exception) {
                synchronized(saveBufferLock) { saveBuffer?.reset(); saveBuffer = null; expectedBase64Length = -1; receivedBase64Length = 0 }
                false
            }
        }

        @android.webkit.JavascriptInterface
        fun finishSaveFile(): Boolean {
            val bytes: ByteArray
            val name: String
            val mime: String
            synchronized(saveBufferLock) {
                val buffer = saveBuffer ?: return false
                if (receivedBase64Length != expectedBase64Length) return false
                bytes = buffer.toByteArray()
                name = saveFileName
                mime = saveMimeType
                saveBuffer = null
                expectedBase64Length = -1
                receivedBase64Length = 0
            }
            runOnUiThread {
                try {
                    pendingSaveBytes = bytes
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mime
                        putExtra(Intent.EXTRA_TITLE, safeExportName(name))
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    }
                    startActivityForResult(intent, saveFileRequest)
                } catch (e: Exception) {
                    pendingSaveBytes = null
                    evaluateEditorJs("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось открыть сохранение") + ")", null)
                }
            }
            return true
        }

        @android.webkit.JavascriptInterface
        fun saveFile(fileName: String, mimeType: String, base64Data: String) {
            runOnUiThread {
                try {
                    val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                    pendingSaveBytes = bytes
                    val safeName = safeExportName(fileName)
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mimeType.ifBlank { "application/octet-stream" }
                        putExtra(Intent.EXTRA_TITLE, safeName)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    }
                    startActivityForResult(intent, saveFileRequest)
                } catch (e: Exception) {
                    pendingSaveBytes = null
                    evaluateEditorJs("window.__opticNativeSaveError && window.__opticNativeSaveError(" + org.json.JSONObject.quote(e.message ?: "Не удалось подготовить файл") + ")", null)
                }
            }
        }
    }

    private fun hexToBytes(s: String): ByteArray = ByteArray(s.length/2) { i -> s.substring(i*2,i*2+2).toInt(16).toByte() }
    override fun onDestroy() {
        tileHttpPool.shutdownNow()
        if (::web.isInitialized && editorWebViewAlive) {
            try { (web.parent as? ViewGroup)?.removeView(web) } catch (_: Exception) { }
            try { web.destroy() } catch (_: Exception) { }
        }
        editorWebViewAlive = false
        super.onDestroy()
    }
}
